# TETRA ARENA 本地裁判

下载并解压裁判包，在含有 `arena/` 的目录运行命令。裁判使用 Python 3.12 标准库。Bot 可以用任何能读写标准输入输出的语言，`examples/` 收录线上支持的 27 种语言示例。

```sh
python -m arena match --seed 42 --replay replay.jsonl
python -m arena verify replay.jsonl
python -m arena verify example-replay.jsonl
python -m arena render replay.jsonl replay.html
python -m arena export-rules public.json
```

`verify` 从种子、落子和记录的思考帧重算整局，`render` 生成可离线打开的 HTML。0.1.0 至 0.5.2 的历史回放继续使用各自记录的规则。重新运行 Bot 时，实测墙钟时间可能因机器而异。正式天梯用相同种子交换座位打第二局，再根据两局结果结算。

## 网页接口与本地入口

网页的天梯、观战和规则页使用同一比赛服务下载裁判。解压后的 `arena/` 可直接运行本地对局，`browser/` 收录与网页同版的 JavaScript 裁判与回放模块，`rules.md` 附有 T 旋过程图。

| 网页功能 | HTTP 接口 | 裁判包或服务行为 |
| --- | --- | --- |
| 运行限制、语言列表、规则指纹 | `GET /api/health` | `python -m arena export-rules public.json` 导出本地规则、几何和 `rules_sha256`，可与服务端指纹比对。 |
| 读取会话 | `GET /api/session` | 比赛服务建立或恢复会话并返回 `csrf_token`。 |
| 注册和登录 | `POST /api/register`、`POST /api/login` | 请求传 `username` 和 `password`。比赛服务返回登录后的会话。 |
| 退出 | `POST /api/logout` | 比赛服务发放新的游客会话。 |
| 排行榜、自己的 Bot | `GET /api/leaderboard`、`GET /api/bots/mine` | 比赛服务保存账号、Bot 版本和 Elo。自己的 Bot 列表需要登录。 |
| 上传 Bot | `POST /api/bots` | 请求传 `name`、`filename`、`source`，可选 `auto_challenge`。本地用 `match --a-command` 和 `--b-command` 直接启动程序。 |
| 近期挑战、发起天梯挑战 | `GET /api/challenges`、`POST /api/challenges` | 发起时传 `bot_id`，可选 `opponent_id`。服务按同一个种子交换座位打两局；本地每次 `match` 打一局。 |
| 自定义对战 | `POST /api/practice` | 请求传 `a_id` 和 `b_id`，打一局并保存私有回放。本地对应 `python -m arena match`。 |
| 比赛摘要 | `GET /api/matches/{id}` | 返回双方、座位和赛果等元数据。 |
| 下载、导入与重算回放 | `GET /api/matches/{id}/replay` | 接口返回 JSONL。本地用 `python -m arena verify replay.jsonl` 校验，或用 `render` 导出；浏览器调用 `browser/replay.mjs` 的 `validateReplay`。 |
| 下载裁判 | `GET /api/referee/download` | 返回 `tetra-referee.zip`。 |

网页的 JSON POST 请求带 `X-CSRF-Token`。同源部署用会话 Cookie，跨域前端用 `Authorization: Bearer <session_token>`。私有自定义对战的摘要和回放都需要发起者会话。

网页本地模拟直接调用 `browser/engine.mjs` 的 `createDuel(seed)`。同模块的 `geometry()` 和 `fingerprint()` 对应本地规则导出，`traceTSpin()` 从锁定前的棋盘和已记录的走法重建旋转。回放取到 JSONL 后可直接交给 `validateReplay(text)` 重算棋盘。浏览器观战只启用当前裁判，旧规则对局保存为历史数据。

## 本轮规则改动

- v0.5.2 将实心行升起排成独立事件。同帧按升实心行并检查出局、发观察、结算到期落块的次序执行。受阻合法键照常计帧，保留上一次成功动作。只有同帧锁定的新攻击才能对冲，双方先各自抵消旧预警。
- v0.5.3 取消免费思考窗。每席位实际耗时每满 1/60 秒计一帧，每手最多 6 帧，保留不足一帧的余量。HOLD 和其后 PLAY 合并计时。
- 默认加时从第 60 秒起每隔 4 秒升一行永久实心行。180 秒到限且双方存活时判平。

## 其他语言的裁判入口

裁判包的 `launchers/` 提供其余 25 种语言的可运行入口。所有入口共用同一个 Python 裁判内核，支持 `match`、`verify`、`render` 和 `export-rules`，并继承标准输入、标准输出和退出码。入口需要对应的编译器或解释器和 Python 3.12。运行脚本会在临时目录构建，默认使用启动它的 Python。环境变量 `TETRA_REFEREE_PYTHON` 可以指定另一个 Python 可执行文件。

```sh
python launchers/run.py list
python launchers/run.py run cpp verify example-replay.jsonl
python launchers/run.py run rust match --seed 42 --replay rust-match.jsonl
python launchers/run.py check --available
```

从源码仓库运行时，脚本路径为 `web/reference/launchers/run.py`。运行 `check` 可校验全部入口，或在命令后列出要校验的语言标识。Lua、Objective-C、Pascal 和 Swift 入口需要 POSIX 环境，.NET 三种语言需要 .NET 8 SDK，TypeScript 使用 Node.js 24。仓库的 Linux CI 使用项目的 Bot 镜像验证全部入口。

## 运行自己的 Bot

`--a-command` 和 `--b-command` 接收一个 JSON 字符串数组，由裁判直接启动命令。例如 Shell 中可运行 Python 对 JavaScript。

```sh
python -m arena match --seed 42 --a-command '["python","examples/starter_bot.py"]' --b-command '["node","examples/starter_bot.js"]' --replay mixed.jsonl
```

Windows 上也可用 Python 传递参数，保留 JSON 字符串内的引号。

```sh
python -c "import json, subprocess, sys; subprocess.run([sys.executable, '-m', 'arena', 'match', '--a-command', json.dumps([sys.executable, 'examples/starter_bot.py']), '--b-command', json.dumps(['node', 'examples/starter_bot.js']), '--seed', '42'], check=True)"
```

先按下表编译需要构建的 Bot。把「运行命令」中的程序和参数写成 JSON 数组，编译文件路径可用作 argv 的第一项。以下构建示例使用 POSIX Shell，运行前先建好输出目录。

```sh
mkdir -p build/java build/scala build/haskell build/pascal
```

| 语言 | 本地构建命令 | 运行命令 |
| --- | --- | --- |
| Bash | 直接运行 | `bash examples/starter_bot.sh` |
| C | `gcc -std=c17 -O2 examples/starter_bot.c -o build/bot-c` | `./build/bot-c` |
| C++ | `g++ -std=c++20 -O2 examples/starter_bot.cpp -o build/bot-cpp` | `./build/bot-cpp` |
| Clojure | 直接运行 | `clojure examples/starter_bot.clj` |
| D | `ldc2 -O2 -of=build/bot-d examples/starter_bot.d` | `./build/bot-d` |
| Dart | `dart compile exe examples/starter_bot.dart -o build/bot-dart` | `./build/bot-dart` |
| Go | `go build -o build/bot-go examples/starter_bot.go` | `./build/bot-go` |
| Groovy | 直接运行 | `groovy examples/starter_bot.groovy` |
| Haskell | `ghc -O2 -outputdir build/haskell -o build/bot-haskell examples/starter_bot.hs` | `./build/bot-haskell` |
| Java | `javac -d build/java examples/Main.java` | `java -cp build/java Main` |
| JavaScript | 直接运行 | `node examples/starter_bot.js` |
| Kotlin | `kotlinc examples/starter_bot.kt -include-runtime -d build/bot-kotlin.jar` | `java -jar build/bot-kotlin.jar` |
| Lua | 直接运行 | `lua examples/starter_bot.lua` |
| Objective-C | `clang -O2 examples/starter_bot.m -o build/bot-objc` | `./build/bot-objc` |
| OCaml | `ocamlopt -I +str str.cmxa examples/starter_bot.ml -o build/bot-ocaml` | `./build/bot-ocaml` |
| Pascal | `fpc -O2 -FUbuild/pascal -obuild/bot-pascal examples/starter_bot.pas` | `./build/bot-pascal` |
| Perl | 直接运行 | `perl examples/starter_bot.pl` |
| PHP | 直接运行 | `php examples/starter_bot.php` |
| Python | 直接运行 | `python examples/starter_bot.py` |
| Ruby | 直接运行 | `ruby examples/starter_bot.rb` |
| Rust | `rustc --edition 2021 -O examples/starter_bot.rs -o build/bot-rust` | `./build/bot-rust` |
| Scala | `scalac -d build/scala examples/starter_bot.scala` | `scala -cp build/scala Main` |
| Swift | `swiftc -O examples/starter_bot.swift -o build/bot-swift` | `./build/bot-swift` |
| TypeScript | 示例可以由 Node.js 24 直接运行 | `node examples/starter_bot.ts` |

C#、F# 和 VB.NET 都使用 .NET 8 SDK。下例构建 C#；F# 用 `-lang 'F#'`、`starter_bot.fs` 和 `Program.fs`；VB.NET 用 `-lang VB`、`starter_bot.vb` 和 `Program.vb`。

```sh
dotnet new console -lang 'C#' --framework net8.0 -n TetraBot -o build/dotnet
cp examples/starter_bot.cs build/dotnet/Program.cs
dotnet build build/dotnet -c Release -o build/dotnet-bin
dotnet build/dotnet-bin/TetraBot.dll
```

例如，构建 C++ 示例后，可与 Python Bot 进行自定义对局。

```sh
python -m arena match --a-command '["./build/bot-cpp"]' --b-command '["python","examples/starter_bot.py"]' --seed 42 --replay mixed.jsonl
```

查看 `public_geometry.json` 获取完整动作几何及规则指纹，从 `rules.md` 了解计分和局面。

Bot 从 stdin 读取一行 JSON，包含 `type: "OBSERVE"`、`request_id`、`remaining_ms`、`bank_ms` 和 `observation`（含 60 FPS 帧号 `frame` 与双方 `next_frame`）。首块首次观察下发完整 `rules` 与 `geometry`，后续观察精简省略。Bot 可回复 `HOLD` 取块再等下一条 OBSERVE，或一次回复 `PLAY` 并提供以 `HARD_DROP` 结束的 `commands`。每行回复带上对应的 `request_id`，末尾换行并 flush。每个 Bot 首块有 1000 ms，之后每块有 100 ms（外加 2000 ms 局内时间池）；思考耗时从开始即按 60 FPS 累积，每累计 1/60 秒折成 1 帧。每手最多 6 帧，超限整帧舍弃，不足一帧的余量给同一席位的下一手。HOLD 和随后落块共用同一手的预算与折帧上限。

本地裁判使用当前账号权限启动传入的命令，适合复现自有或可信的 Bot。线上天梯接收单个最大 256 KiB 的 UTF-8 源文件，在独立 Docker 容器中构建并运行。编译在 Bot 思考计时开始前完成。
