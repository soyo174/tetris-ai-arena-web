using System;
using System.Diagnostics;

var python = Environment.GetEnvironmentVariable("TETRA_REFEREE_PYTHON");
var options = new ProcessStartInfo(string.IsNullOrEmpty(python) ? "python3" : python);
options.UseShellExecute = false;
options.ArgumentList.Add("-m");
options.ArgumentList.Add("arena");
foreach (var argument in args) options.ArgumentList.Add(argument);
using var child = Process.Start(options)!;
child.WaitForExit();
return child.ExitCode;
