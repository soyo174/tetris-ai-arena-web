program Referee;
{$mode objfpc}{$H+}
uses BaseUnix, SysUtils, Unix;

var
  i: Integer;
  args: array of AnsiString;
  vector: array of PChar;
begin
  SetLength(args, ParamCount + 3);
  args[0] := GetEnvironmentVariable('TETRA_REFEREE_PYTHON');
  if args[0] = '' then args[0] := 'python3';
  args[1] := '-m';
  args[2] := 'arena';
  for i := 1 to ParamCount do args[i + 2] := ParamStr(i);
  SetLength(vector, Length(args) + 1);
  for i := 0 to High(args) do vector[i] := PChar(args[i]);
  vector[High(vector)] := nil;
  fpExecVP(args[0], @vector[0]);
  WriteLn(StdErr, SysErrorMessage(fpGetErrNo));
  Halt(127);
end.
