#!/usr/bin/env bash
exec "${TETRA_REFEREE_PYTHON:-python3}" -m arena "$@"
