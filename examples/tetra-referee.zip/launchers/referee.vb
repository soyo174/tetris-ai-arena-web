Imports System
Imports System.Diagnostics

Module Referee
    Function Main(args As String()) As Integer
        Dim python = Environment.GetEnvironmentVariable("TETRA_REFEREE_PYTHON")
        Dim options As New ProcessStartInfo(If(String.IsNullOrEmpty(python), "python3", python))
        options.UseShellExecute = False
        options.ArgumentList.Add("-m")
        options.ArgumentList.Add("arena")
        For Each argument In args
            options.ArgumentList.Add(argument)
        Next
        Using child = Process.Start(options)
            child.WaitForExit()
            Return child.ExitCode
        End Using
    End Function
End Module
