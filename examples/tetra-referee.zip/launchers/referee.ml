let () =
  let python = match Sys.getenv_opt "TETRA_REFEREE_PYTHON" with
    | Some path when path <> "" -> path
    | _ -> "python3"
  in
  let args = Array.sub Sys.argv 1 (Array.length Sys.argv - 1) in
  Unix.execvp python (Array.append [| python; "-m"; "arena" |] args)
