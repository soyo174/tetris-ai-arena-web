use std::env;
use std::process::{self, Command};

fn main() {
    let python = env::var_os("TETRA_REFEREE_PYTHON").unwrap_or_else(|| "python3".into());
    let status = Command::new(python)
        .args(["-m", "arena"])
        .args(env::args_os().skip(1))
        .status();
    match status {
        Ok(code) => process::exit(code.code().unwrap_or(1)),
        Err(error) => {
            eprintln!("{error}");
            process::exit(127);
        }
    }
}
