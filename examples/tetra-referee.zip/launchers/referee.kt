import kotlin.system.exitProcess

fun main(args: Array<String>) {
    val python = System.getenv("TETRA_REFEREE_PYTHON").orEmpty().ifEmpty { "python3" }
    val command = listOf(python, "-m", "arena") + args
    exitProcess(ProcessBuilder(command).inheritIO().start().waitFor())
}
