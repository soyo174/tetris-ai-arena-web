python = ENV.fetch('TETRA_REFEREE_PYTHON', 'python3')
exec(python, '-m', 'arena', *ARGV)
