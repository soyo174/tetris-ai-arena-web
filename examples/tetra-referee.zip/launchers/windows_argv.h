#ifndef TETRA_WINDOWS_ARGV_H
#define TETRA_WINDOWS_ARGV_H

#include <process.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>

/* _wspawnvp joins argv with spaces. Supply CRT-compatible quoting for each token. */
static wchar_t *tetra_quote(const wchar_t *value) {
    wchar_t *quoted = (wchar_t *)malloc((2 * wcslen(value) + 3) * sizeof(wchar_t));
    if (!quoted) return NULL;
    wchar_t *out = quoted;
    *out++ = L'"';
    for (;;) {
        size_t slashes = 0;
        while (*value == L'\\') {
            ++slashes;
            ++value;
        }
        if (*value == L'"' || !*value) slashes *= 2;
        while (slashes > 0) {
            *out++ = L'\\';
            --slashes;
        }
        if (!*value) break;
        if (*value == L'"') *out++ = L'\\';
        *out++ = *value++;
    }
    *out++ = L'"';
    *out = L'\0';
    return quoted;
}

static int tetra_run_windows(int argc, wchar_t **argv) {
    const wchar_t *python = _wgetenv(L"TETRA_REFEREE_PYTHON");
    if (!python || !*python) python = L"python3";
    const wchar_t **args = (const wchar_t **)calloc((size_t)argc + 3, sizeof(*args));
    if (!args) return 1;
    int result = 1;
    for (int i = 0; i < argc + 2; ++i) {
        const wchar_t *value = i == 0 ? python : i == 1 ? L"-m" : i == 2 ? L"arena" : argv[i - 2];
        args[i] = tetra_quote(value);
        if (!args[i]) goto done;
    }
    {
        const intptr_t status = _wspawnvp(_P_WAIT, python, args);
        if (status < 0) {
            _wperror(python);
            result = 127;
        } else {
            result = (int)status;
        }
    }
done:
    for (int i = 0; i < argc + 2; ++i) free((void *)args[i]);
    free(args);
    return result;
}

#endif
