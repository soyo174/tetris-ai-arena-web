import Foundation

let python = ProcessInfo.processInfo.environment["TETRA_REFEREE_PYTHON"] ?? "python3"
let child = Process()
child.executableURL = URL(fileURLWithPath: "/usr/bin/env")
child.arguments = [python, "-m", "arena"] + Array(CommandLine.arguments.dropFirst())
try child.run()
child.waitUntilExit()
exit(child.terminationStatus)
