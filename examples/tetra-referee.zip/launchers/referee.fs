open System
open System.Diagnostics

[<EntryPoint>]
let main args =
    let python = Environment.GetEnvironmentVariable("TETRA_REFEREE_PYTHON")
    let program = if String.IsNullOrEmpty(python) then "python3" else python
    let options = ProcessStartInfo(program, UseShellExecute = false)
    for argument in Array.append [| "-m"; "arena" |] args do
        options.ArgumentList.Add(argument)
    use child = Process.Start(options)
    child.WaitForExit()
    child.ExitCode
