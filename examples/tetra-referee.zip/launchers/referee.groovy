def python = System.getenv('TETRA_REFEREE_PYTHON') ?: 'python3'
def command = [python, '-m', 'arena'] + args.toList()
System.exit(new ProcessBuilder(command).inheritIO().start().waitFor())
