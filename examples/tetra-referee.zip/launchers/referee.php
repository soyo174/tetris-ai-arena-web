<?php
$python = getenv('TETRA_REFEREE_PYTHON') ?: 'python3';
$command = array_merge([$python, '-m', 'arena'], array_slice($argv, 1));
$child = proc_open($command, [STDIN, STDOUT, STDERR], $pipes);
exit(is_resource($child) ? proc_close($child) : 127);
