#ifdef _WIN32
#include "windows_argv.h"

int wmain(int argc, wchar_t **argv) {
    return tetra_run_windows(argc, argv);
}
#else
#include <cstdio>
#include <cstdlib>
#include <string>
#include <unistd.h>
#include <vector>

int main(int argc, char **argv) {
    const char *configured = std::getenv("TETRA_REFEREE_PYTHON");
    std::string python = configured && *configured ? configured : "python3";
    char module_flag[] = "-m";
    char module_name[] = "arena";
    std::vector<char *> args{python.data(), module_flag, module_name};
    args.insert(args.end(), argv + 1, argv + argc);
    args.push_back(nullptr);
    execvp(python.c_str(), args.data());
    std::perror(python.c_str());
    return 127;
}
#endif
