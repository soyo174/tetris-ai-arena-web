import System.Environment (getArgs, lookupEnv)
import System.Exit (exitWith)
import System.Process (rawSystem)

main :: IO ()
main = do
    configured <- lookupEnv "TETRA_REFEREE_PYTHON"
    args <- getArgs
    let python = case configured of
            Just path | not (null path) -> path
            _ -> "python3"
    rawSystem python (["-m", "arena"] ++ args) >>= exitWith
