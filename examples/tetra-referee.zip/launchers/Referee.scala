object Referee {
  def main(args: Array[String]): Unit = {
    val python = sys.env.get("TETRA_REFEREE_PYTHON").filter(_.nonEmpty).getOrElse("python3")
    val command = Array(python, "-m", "arena") ++ args
    val child = new java.lang.ProcessBuilder(command: _*).inheritIO().start()
    sys.exit(child.waitFor())
  }
}
