-- Lua's standard library exposes a shell command, so quote every argv element.
local function quote(value)
    return "'" .. value:gsub("'", "'\\''") .. "'"
end

local python = os.getenv("TETRA_REFEREE_PYTHON") or "python3"
local command = {quote(python), "-m", "arena"}
for _, argument in ipairs(arg) do
    command[#command + 1] = quote(argument)
end
-- Let the shell report the child's status explicitly while inheriting all
-- three streams. Some Lua builds report errno after a nonzero child exit.
local status_path = assert(os.tmpname())
os.execute(table.concat(command, " ") .. "; printf '%s' \"$?\" > " .. quote(status_path))
local result = io.open(status_path, "r")
local status = result and result:read("*n")
if result then result:close() end
os.remove(status_path)
os.exit(status or 127)
