import {spawnSync} from 'node:child_process';

const python: string = process.env.TETRA_REFEREE_PYTHON || 'python3';
const child = spawnSync(python, ['-m', 'arena', ...process.argv.slice(2)], {stdio: 'inherit'});
if (child.error) {
  console.error(child.error.message);
  process.exitCode = 127;
} else {
  process.exitCode = child.status ?? 1;
}
