import std.process : environment, spawnProcess, wait;

int main(string[] args) {
    auto python = environment.get("TETRA_REFEREE_PYTHON", "python3");
    return wait(spawnProcess([python, "-m", "arena"] ~ args[1 .. $]));
}
