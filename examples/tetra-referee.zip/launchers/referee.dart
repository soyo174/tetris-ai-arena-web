import 'dart:io';

Future<void> main(List<String> args) async {
  final python = Platform.environment['TETRA_REFEREE_PYTHON'] ?? 'python3';
  final child = await Process.start(
    python,
    ['-m', 'arena', ...args],
    mode: ProcessStartMode.inheritStdio,
  );
  exitCode = await child.exitCode;
}
