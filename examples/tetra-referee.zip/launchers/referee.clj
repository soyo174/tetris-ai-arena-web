(def python (or (not-empty (System/getenv "TETRA_REFEREE_PYTHON")) "python3"))
(def command (into [python "-m" "arena"] *command-line-args*))
(def builder (ProcessBuilder. ^java.util.List command))
(System/exit (.waitFor (.start (.inheritIO builder))))
