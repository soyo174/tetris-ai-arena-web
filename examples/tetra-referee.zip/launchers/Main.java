import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) throws Exception {
        String python = System.getenv("TETRA_REFEREE_PYTHON");
        if (python == null || python.isEmpty()) python = "python3";
        List<String> command = new ArrayList<>(List.of(python, "-m", "arena"));
        command.addAll(Arrays.asList(args));
        System.exit(new ProcessBuilder(command).inheritIO().start().waitFor());
    }
}
