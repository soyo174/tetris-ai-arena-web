"""Build and run the 25 local entry points for the shared Python referee."""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory


DIRECTORY = Path(__file__).resolve().parent
LANGUAGES = {
    "bash": "referee.sh",
    "c": "referee.c",
    "clojure": "referee.clj",
    "cpp": "referee.cpp",
    "csharp": "referee.cs",
    "d": "referee.d",
    "dart": "referee.dart",
    "fsharp": "referee.fs",
    "go": "referee.go",
    "groovy": "referee.groovy",
    "haskell": "referee.hs",
    "java": "Main.java",
    "kotlin": "referee.kt",
    "lua": "referee.lua",
    "objectivec": "referee.m",
    "ocaml": "referee.ml",
    "pascal": "referee.pas",
    "perl": "referee.pl",
    "php": "referee.php",
    "ruby": "referee.rb",
    "rust": "referee.rs",
    "scala": "Referee.scala",
    "swift": "referee.swift",
    "typescript": "referee.ts",
    "vbnet": "referee.vb",
}
DIRECT = {"bash": ("bash",), "clojure": ("clojure",), "dart": ("dart",),
          "perl": ("perl",), "php": ("php",), "ruby": ("ruby",), "lua": ("lua5.4", "lua")}
DOTNET = {"csharp", "fsharp", "vbnet"}
POSIX_ONLY = {"lua", "objectivec", "pascal", "swift"}


class ToolUnavailable(Exception):
    """The host lacks a compiler or interpreter needed for this entry point."""


def tool(*names, fallback=None):
    for name in names:
        found = shutil.which(name)
        if found:
            return found
    if fallback and fallback.is_file():
        return str(fallback)
    raise ToolUnavailable(" / ".join(names))


def compile_source(work, *command):
    subprocess.run(command, cwd=work, check=True, timeout=180)


def dotnet_command(language, source, work):
    dotnet = tool("dotnet", fallback=Path("/usr/share/dotnet/dotnet"))
    sdks = subprocess.check_output([dotnet, "--list-sdks"], text=True).splitlines()
    dotnet8 = [sdk for sdk in sdks if sdk.startswith("8.") and " [" in sdk]
    if not dotnet8:
        raise ToolUnavailable(".NET 8 SDK")
    version, sdk_root = dotnet8[-1].removesuffix("]").split(" [", 1)
    sdk_directory = Path(sdk_root) / version
    framework_packs = Path(sdk_root).parent / "packs/Microsoft.NETCore.App.Ref"
    reference_packs = [
        path for path in framework_packs.glob("8.*")
        if all(part.isdigit() for part in path.name.split(".")) and (path / "ref/net8.0").is_dir()
    ]
    if not reference_packs:
        raise ToolUnavailable(".NET 8 reference assemblies")
    framework = max(reference_packs, key=lambda path: tuple(map(int, path.name.split("."))))
    reference_dir = framework / "ref/net8.0"
    references = [f"-r:{path}" for path in sorted(reference_dir.glob("*.dll"))]
    target = work / "Referee.dll"

    if language == "fsharp":
        compiler = sdk_directory / "FSharp/fsc.dll"
        library = sdk_directory / "FSharp/FSharp.Core.dll"
        shutil.copyfile(library, work / library.name)
        flags = ("--targetprofile:netcore", "--noframework", "--target:exe", "--optimize+",
                 f"--out:{target}", f"-r:{library}")
    else:
        compiler = sdk_directory / "Roslyn/bincore" / ("csc.dll" if language == "csharp" else "vbc.dll")
        flags = ("-nologo", "-noconfig", "-nostdlib", "-target:exe", "-optimize+", f"-out:{target}")
        if language == "csharp":
            flags += ("-nullable:enable",)
        else:
            flags += ('-optioninfer+', '-define:_MYTYPE="Empty"', f"-vbruntime:{reference_dir / 'Microsoft.VisualBasic.Core.dll'}")

    # Use the bundled compilers directly, as for sandboxed .NET Bots.
    compile_source(work, dotnet, "exec", str(compiler), *flags, *references, source.name)
    target.with_suffix(".runtimeconfig.json").write_text(json.dumps({
        "runtimeOptions": {"tfm": "net8.0", "framework": {"name": "Microsoft.NETCore.App", "version": "8.0.0"}},
    }), encoding="utf-8")
    return [dotnet, "exec", str(target)]


def jvm_command(language, source, work):
    java = tool("java")
    if language == "java":
        compile_source(work, tool("javac"), "-encoding", "UTF-8", "-d", str(work), str(source))
        return [java, "-cp", str(work), "Main"]
    if language == "kotlin":
        kotlin = tool("kotlinc", fallback=Path("/opt/tetra/kotlinc/bin/kotlinc"))
        jar = work / "referee.jar"
        compile_source(work, kotlin, str(source), "-include-runtime", "-d", str(jar))
        return [java, "-jar", str(jar)]
    if language == "groovy":
        groovy = shutil.which("groovy")
        if groovy:
            return [groovy, str(source)]
        if Path("/opt/tetra/groovy/groovy.jar").is_file():
            return [java, "-cp", "/opt/tetra/groovy/*", "groovy.ui.GroovyMain", str(source)]
        raise ToolUnavailable("Groovy")
    if Path("/opt/tetra/scala/scala-compiler.jar").is_file():
        scala_jars = "/opt/tetra/scala/*"
        compile_source(work, java, "-cp", scala_jars, "scala.tools.nsc.Main", "-usejavacp",
                       "-d", str(work), str(source))
        return [java, "-cp", os.pathsep.join((str(work), scala_jars)), "Referee"]
    scalac, scala = tool("scalac"), tool("scala")
    compile_source(work, scalac, "-d", str(work), str(source))
    return [scala, "-cp", str(work), "Referee"]


def native_command(language, source, work):
    output = str(work / ("referee.exe" if os.name == "nt" else "referee"))
    path = str(source)
    if language in {"c", "cpp", "objectivec"}:
        cpp = language == "cpp"
        msvc = shutil.which("cl") if os.name == "nt" else None
        if msvc:
            options = ["/std:c++20", "/EHsc"] if cpp else ["/std:c17"]
            return [msvc, "/nologo", "/O2", *options, path, f"/Fe:{output}"], output
        compiler = tool("g++", "clang++") if cpp else tool("gcc", "clang")
        unicode_entry = ["-municode"] if os.name == "nt" else []
        return [compiler, "-std=c++20" if cpp else "-std=c17", "-O2", *unicode_entry, path, "-o", output], output
    if language == "d":
        return [tool("ldc2", "ldc"), "-O2", f"-of={output}", path], output
    if language == "go":
        return [tool("go"), "build", "-o", output, path], output
    if language == "haskell":
        return [tool("ghc"), "-O2", "-outputdir", str(work), path, "-o", output], output
    if language == "ocaml":
        return [tool("ocamlopt"), "-I", "+unix", "unix.cmxa", path, "-o", output], output
    if language == "pascal":
        return [tool("fpc"), "-O2", f"-FU{work}", f"-o{output}", path], output
    if language == "rust":
        return [tool("rustc"), "--edition", "2021", "-O", path, "-o", output], output
    if language == "swift":
        return [tool("swiftc"), "-O", path, "-o", output], output
    raise ValueError(f"unknown native entry point: {language}")


def build(language, work):
    if language in POSIX_ONLY and os.name != "posix":
        raise ToolUnavailable("POSIX host")
    source = work / LANGUAGES[language]
    source.write_text((DIRECTORY / source.name).read_text(encoding="utf-8"), encoding="utf-8", newline="\n")
    if language in {"c", "cpp"} and os.name == "nt":
        shutil.copyfile(DIRECTORY / "windows_argv.h", work / "windows_argv.h")
    if language == "objectivec":
        shutil.copyfile(DIRECTORY / LANGUAGES["c"], work / LANGUAGES["c"])
    if language in DIRECT:
        fallback = Path("/opt/tetra/dart/bin/dart") if language == "dart" else None
        if os.name == "nt" and language in {"bash", "perl"}:
            git = shutil.which("git")
            if git:
                folder = "bin" if language == "bash" else "usr/bin"
                fallback = Path(git).resolve().parents[1] / folder / f"{language}.exe"
        return [tool(*DIRECT[language], fallback=fallback), str(source)]
    if language in DOTNET:
        return dotnet_command(language, source, work)
    if language in {"java", "kotlin", "groovy", "scala"}:
        return jvm_command(language, source, work)
    if language == "typescript":
        node = tool("node", fallback=Path("/usr/local/bin/node"))
        version = subprocess.check_output([node, "--version"], text=True).strip()
        if int(version.lstrip("v").split(".", 1)[0]) < 24:
            raise ToolUnavailable("Node.js 24 or newer")
        return [node, str(source)]
    command, output = native_command(language, source, work)
    compile_source(work, *command)
    return [output]


def referee_environment():
    reference = DIRECTORY.parent
    package = reference if (reference / "arena").is_dir() else reference / "python"
    if not (package / "arena" / "__main__.py").is_file():
        raise FileNotFoundError("shared arena package is missing")
    env = os.environ.copy()
    env["TETRA_REFEREE_PYTHON"] = env.get("TETRA_REFEREE_PYTHON") or Path(sys.executable).as_posix()
    env["PYTHONPATH"] = os.pathsep.join(filter(None, (str(package), env.get("PYTHONPATH"))))
    # Git for Windows otherwise rewrites paths embedded in JSON arguments.
    if os.name == "nt":
        env["MSYS2_ARG_CONV_EXCL"] = "*"
    return env


def check(command, work, env):
    reference = DIRECTORY.parent
    fixture = reference / "example-replay.jsonl"
    if not fixture.is_file():
        fixture = reference.parent / "tests/fixtures/greedy_random_v2_seed42.jsonl"
    expected_rules = json.loads((reference / "public_geometry.json").read_text(encoding="utf-8"))
    exported = work / "rules with ' quotes.json"
    subprocess.run([*command, "export-rules", str(exported)], env=env, check=True, timeout=60)
    if json.loads(exported.read_text(encoding="utf-8")) != expected_rules:
        raise RuntimeError("exported rules differ from the shared profile")
    verified = subprocess.check_output([*command, "verify", str(fixture.resolve())], env=env, timeout=60)
    if json.loads(verified) != {"verified_turns": 18, "winner": 0}:
        raise RuntimeError("historical replay produced an unexpected result")
    invalid = subprocess.run([*command, "invalid command"], env=env, capture_output=True, timeout=60)
    if invalid.returncode != 2 or not invalid.stderr:
        raise RuntimeError(
            f"expected exit 2 and error output, got exit {invalid.returncode} and {len(invalid.stderr)} stderr bytes"
        )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("list", help="list supported language identifiers")
    launch = commands.add_parser("run", help="build one entry point and pass through referee arguments")
    launch.add_argument("language", choices=LANGUAGES)
    launch.add_argument("args", nargs=argparse.REMAINDER, help="arguments for python -m arena")
    smoke = commands.add_parser("check", help="build and smoke-test language entry points")
    smoke.add_argument("languages", nargs="*", metavar="LANGUAGE")
    smoke.add_argument("--available", action="store_true", help="skip SDKs absent on this host")
    args = parser.parse_args()
    if args.command == "list":
        print(*LANGUAGES, sep="\n")
        return 0
    env = referee_environment()
    if args.command == "run":
        try:
            with TemporaryDirectory(prefix="tetra-referee-") as folder:
                command = build(args.language, Path(folder))
                return subprocess.call([*command, *args.args], env=env)
        except ToolUnavailable as exc:
            parser.exit(1, f"{args.language}: required tool unavailable: {exc}\n")
    languages = args.languages or LANGUAGES
    invalid = set(languages) - LANGUAGES.keys()
    if invalid:
        parser.error(f"unknown languages: {', '.join(sorted(invalid))}")
    failures = 0
    for language in languages:
        try:
            with TemporaryDirectory(prefix="tetra-referee-") as folder:
                work = Path(folder)
                check(build(language, work), work, env)
            print(f"PASS {language}", flush=True)
        except ToolUnavailable as exc:
            if not args.available:
                failures += 1
            action = "SKIP" if args.available else "FAIL"
            print(f"{action} {language}: required tool unavailable: {exc}", flush=True)
        except subprocess.CalledProcessError as exc:
            failures += 1
            print(f"FAIL {language}: {exc.cmd[0]} exited with status {exc.returncode}", flush=True)
        except (OSError, RuntimeError, subprocess.SubprocessError) as exc:
            failures += 1
            print(f"FAIL {language}: {exc}", flush=True)
    return int(bool(failures))


if __name__ == "__main__":
    sys.exit(main())
