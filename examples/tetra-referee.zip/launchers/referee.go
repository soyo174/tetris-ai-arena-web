package main

import (
	"errors"
	"fmt"
	"os"
	"os/exec"
)

func main() {
	python := os.Getenv("TETRA_REFEREE_PYTHON")
	if python == "" {
		python = "python3"
	}
	child := exec.Command(python, append([]string{"-m", "arena"}, os.Args[1:]...)...)
	child.Stdin, child.Stdout, child.Stderr = os.Stdin, os.Stdout, os.Stderr
	if err := child.Run(); err != nil {
		var exitError *exec.ExitError
		if errors.As(err, &exitError) && exitError.ExitCode() >= 0 {
			os.Exit(exitError.ExitCode())
		}
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
