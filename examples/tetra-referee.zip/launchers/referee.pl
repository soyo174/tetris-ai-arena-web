use strict;
use warnings;

my $python = $ENV{TETRA_REFEREE_PYTHON} || 'python3';
exec {$python} $python, '-m', 'arena', @ARGV;
die "Unable to start $python: $!";
