#ifdef _WIN32
#include "windows_argv.h"

int wmain(int argc, wchar_t **argv) {
    return tetra_run_windows(argc, argv);
}
#else
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char **argv) {
    char *python = getenv("TETRA_REFEREE_PYTHON");
    if (!python || !*python) python = "python3";
    char **args = calloc((size_t)argc + 3, sizeof(*args));
    if (!args) return 1;
    args[0] = python;
    args[1] = "-m";
    args[2] = "arena";
    for (int i = 1; i < argc; ++i) args[i + 2] = argv[i];
    execvp(python, args);
    perror(python);
    free(args);
    return 127;
}
#endif
