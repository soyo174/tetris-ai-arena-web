/* The C entry point also forms a valid Objective-C translation unit. */
#include "referee.c"
