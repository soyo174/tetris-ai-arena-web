"""Public geometry; y points UP, orientations 0,R,2,L = 0,1,2,3.

90-degree kicks use the SRS convention; v4 180-degree kicks use directional SRS+.
The complete numeric tables are exported to bots, without external dependencies.
"""
SPAWN = {
    "T": ((0, 1), (1, 1), (2, 1), (1, 2)),
    "J": ((0, 1), (1, 1), (2, 1), (0, 2)),
    "L": ((0, 1), (1, 1), (2, 1), (2, 2)),
    "S": ((0, 1), (1, 1), (1, 2), (2, 2)),
    "Z": ((1, 1), (2, 1), (0, 2), (1, 2)),
    "I": ((0, 2), (1, 2), (2, 2), (3, 2)),
    "O": ((1, 1), (2, 1), (1, 2), (2, 2)),
}


def orientations(piece):
    cells = SPAWN[piece]
    result = [cells]
    # Twice the pivot coordinate; integer math even for I's (1.5,1.5).
    pivot2 = 3 if piece in "IO" else 2
    for _ in range(3):
        cells = (SPAWN["O"] if piece == "O" else
                 tuple((y, pivot2-x) for x, y in cells))
        result.append(cells)
    return tuple(result)


CELLS = {p: orientations(p) for p in SPAWN}
JLSTZ_KICKS = {
    (0, 1): ((0, 0), (-1, 0), (-1, 1), (0, -2), (-1, -2)),
    (1, 0): ((0, 0), (1, 0), (1, -1), (0, 2), (1, 2)),
    (1, 2): ((0, 0), (1, 0), (1, -1), (0, 2), (1, 2)),
    (2, 1): ((0, 0), (-1, 0), (-1, 1), (0, -2), (-1, -2)),
    (2, 3): ((0, 0), (1, 0), (1, 1), (0, -2), (1, -2)),
    (3, 2): ((0, 0), (-1, 0), (-1, -1), (0, 2), (-1, 2)),
    (3, 0): ((0, 0), (-1, 0), (-1, -1), (0, 2), (-1, 2)),
    (0, 3): ((0, 0), (1, 0), (1, 1), (0, -2), (1, -2)),
}
I_KICKS = {
    (0, 1): ((0, 0), (-2, 0), (1, 0), (-2, -1), (1, 2)),
    (1, 0): ((0, 0), (2, 0), (-1, 0), (2, 1), (-1, -2)),
    (1, 2): ((0, 0), (-1, 0), (2, 0), (-1, 2), (2, -1)),
    (2, 1): ((0, 0), (1, 0), (-2, 0), (1, -2), (-2, 1)),
    (2, 3): ((0, 0), (2, 0), (-1, 0), (2, 1), (-1, -2)),
    (3, 2): ((0, 0), (-2, 0), (1, 0), (-2, -1), (1, 2)),
    (3, 0): ((0, 0), (1, 0), (-2, 0), (1, -2), (-2, 1)),
    (0, 3): ((0, 0), (-1, 0), (2, 0), (-1, 2), (2, -1)),
}


def kicks(piece, old, new, rules):
    if (new - old) % 4 == 2:
        if isinstance(rules.kicks_180, dict):
            return rules.kicks_180[f"{old}:{new}"]
        return rules.kicks_180
    override = rules.kicks_90_override.get(f"{piece}:{old}:{new}")
    if override is not None:
        return override
    if piece == "O":
        return ((0, 0),)
    return (I_KICKS if piece == "I" else JLSTZ_KICKS)[old, new]


def geometry(rules):
    return {"cells": CELLS,
            "pivots": {p: ([1.5, 1.5] if p in "IO" else [1, 1]) for p in SPAWN},
            "kicks_90": {p: {f"{a}:{b}": kicks(p, a, b, rules)
                              for a in range(4) for b in range(4)
                              if (b-a) % 4 in (1, 3)} for p in SPAWN},
            "kicks_180": rules.kicks_180,
            "coordinate_system": "0-based; rows bottom-to-top; y-up"}
