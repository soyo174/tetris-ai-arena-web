"""Strict JSON-lines, one request -> one HOLD/PLAY response."""
import json
from .actions import ProgramError, validate

PROTOCOL = "tetris-duel-jsonl-v1"


def _unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ProgramError("duplicate JSON key")
        result[key] = value
    return result


def _reject_constant(value):
    raise ProgramError(f"nonfinite JSON constant: {value}")


def parse_response(raw, request_id, rules):
    if not raw or len(raw) > rules.max_response_bytes or not raw.endswith(b"\n"):
        raise ProgramError("empty/oversized/incomplete response")
    try:
        response = json.loads(raw.decode("utf-8"), object_pairs_hook=_unique,
                              parse_constant=_reject_constant)
    except (ValueError, UnicodeError, RecursionError) as exc:
        raise ProgramError("invalid JSON response") from exc
    if not isinstance(response, dict):
        raise ProgramError("response must be an object")
    if response.get("request_id") != request_id:
        raise ProgramError("stale or wrong request_id")
    kind = response.get("type")
    if kind == "HOLD" and set(response) == {"request_id", "type"}:
        return kind, None
    if kind == "PLAY" and set(response) == {"request_id", "type", "commands"}:
        validate(response["commands"], rules)
        return kind, response["commands"]
    raise ProgramError("unknown response type or fields")
