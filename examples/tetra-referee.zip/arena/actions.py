"""Routes are validated before any mutation. Blocked legal steps are no-ops."""
from dataclasses import dataclass
from .pieces import CELLS, kicks

MOVES = {"LEFT", "RIGHT", "DOWN", "CW", "CCW", "ROT180", "HARD_DROP"}


class ProgramError(ValueError):
    pass


def validate(commands, rules):
    if not isinstance(commands, list) or not 1 <= len(commands) <= rules.max_commands:
        raise ProgramError("commands must be a nonempty bounded list")
    if any(not isinstance(c, str) or c not in MOVES for c in commands):
        raise ProgramError("unknown instruction")
    if commands[-1] != "HARD_DROP" or "HARD_DROP" in commands[:-1]:
        raise ProgramError("route must end with exactly one HARD_DROP")


@dataclass(frozen=True)
class Pose:
    piece: str
    x: int
    y: int
    rotation: int = 0
    last: str = "SPAWN"
    kick_index: int = 0  # 1-based, meaningful only for last ROT90/ROT180

    def cells(self):
        return tuple((self.x+x, self.y+y) for x, y in CELLS[self.piece][self.rotation])


def spawn(piece, rules):
    return Pose(piece, *rules.spawn_origins[piece])


def step(board, pose, command, rules):
    if command in ("LEFT", "RIGHT", "DOWN"):
        dx, dy = {"LEFT": (-1, 0), "RIGHT": (1, 0), "DOWN": (0, -1)}[command]
        moved = Pose(pose.piece, pose.x+dx, pose.y+dy, pose.rotation, "MOVE")
        return moved if board.fits(moved.cells()) else pose
    if command in ("CW", "CCW", "ROT180"):
        delta = {"CW": 1, "CCW": -1, "ROT180": 2}[command]
        rotation = (pose.rotation + delta) % 4
        for i, (dx, dy) in enumerate(kicks(pose.piece, pose.rotation, rotation, rules), 1):
            moved = Pose(pose.piece, pose.x+dx, pose.y+dy, rotation,
                         "ROT180" if delta == 2 else "ROT90", i)
            if board.fits(moved.cells()):
                return moved
        return pose
    if command == "HARD_DROP":
        while True:
            moved = Pose(pose.piece, pose.x, pose.y-1, pose.rotation, "DROP")
            if not board.fits(moved.cells()):
                return pose
            pose = moved
    raise ProgramError("unknown instruction")


def tspin(board, pose, lines):
    """Inspect pre-clear board. Pose cells need not already be locked."""
    if pose.piece != "T" or pose.last not in ("ROT90", "ROT180"):
        return "none"
    cx, cy = pose.x+1, pose.y+1
    corners = {(dx, dy): board.occupied_corner(cx+dx, cy+dy)
               for dx in (-1, 1) for dy in (-1, 1)}
    if sum(corners.values()) < 3:
        return "none"
    fronts = (((-1, 1), (1, 1)), ((1, 1), (1, -1)),
              ((-1, -1), (1, -1)), ((-1, 1), (-1, -1)))[pose.rotation]
    if (all(corners[p] for p in fronts) or lines >= 2
            or (pose.last == "ROT90" and pose.kick_index == 5)):
        return "full"
    return "mini"


@dataclass(frozen=True)
class LockResult:
    pose: Pose
    lines: int
    spin: str
    perfect_clear: bool


def execute(board, piece, commands, rules):
    validate(commands, rules)
    pose = spawn(piece, rules)
    if not board.fits(pose.cells()):
        raise ProgramError("spawn_blocked")
    for command in commands:
        pose = step(board, pose, command, rules)
    board.lock(pose.cells())
    lines = len(board.full_rows())
    spin = tspin(board, pose, lines)
    board.clear()
    return LockResult(pose, lines, spin, board.empty())
