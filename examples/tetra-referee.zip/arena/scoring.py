from dataclasses import dataclass


@dataclass
class Chain:
    combo: int = 0
    b2b: bool = False


def combo_bonus(combo):
    if combo <= 2:
        return 0
    if combo <= 5:
        return 1
    if combo <= 7:
        return 2
    if combo <= 9:
        return 3
    if combo <= 12:
        return 4
    return 5


def score(lines, spin, perfect_clear, chain, rules):
    if type(lines) is not int or not 0 <= lines <= 4 or spin not in ("none", "mini", "full"):
        raise ValueError("invalid clear result")
    if spin != "none" and lines > 3:
        raise ValueError("T cannot clear four lines")
    if not lines:
        chain.combo = 0
        return 0  # no-clear preserves B2B
    chain.combo += 1
    difficult = lines == 4 or (spin == "full" or (spin == "mini" and lines >= 2))
    attack = (rules.tspin_attack[lines] if spin != "none" and (spin == "full" or lines >= 2)
              else rules.normal_attack[lines])
    if difficult:
        attack += rules.b2b_bonus if chain.b2b else 0
        chain.b2b = True
    elif spin != "mini":
        chain.b2b = False
    attack += combo_bonus(chain.combo)
    return max(attack, rules.perfect_clear_floor) if perfect_clear else attack
