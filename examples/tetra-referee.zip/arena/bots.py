"""Two deliberately small baselines; stdout is reserved for the protocol."""
import json
import random
import sys
from .actions import ProgramError, execute
from .board import Board, EMPTY, SOLID
from .config import Rules


def candidates(piece, rows, rules):
    # Simple spawn rotation -> horizontal moves -> hard drop. This is a legal
    # subset, deliberately not a complete tuck/spin search or competitive AI.
    for rotation in ([], ["CW"], ["ROT180"], ["CCW"]):
        for shift in range(-5, 6):
            commands = rotation + ["LEFT" if shift < 0 else "RIGHT"] * abs(shift) + ["HARD_DROP"]
            board = Board(rows)
            try:
                result = execute(board, piece, commands, rules)
            except ProgramError:
                continue
            yield commands, board, result


def evaluate(board, result):
    # Ignore an overtime solid base when counting holes/heights.
    base = 0
    while base < 24 and all(c == SOLID for c in board.rows[base]):
        base += 1
    heights, holes = [], 0
    for x in range(10):
        h = next((y+1 for y in range(23, base-1, -1) if board.rows[y][x]), base)
        heights.append(h-base)
        holes += sum(board.rows[y][x] == EMPTY for y in range(base, h))
    return (1.2 * result.lines - 0.52*sum(heights) - 2.8*holes
            - 0.22*sum(abs(a-b) for a, b in zip(heights, heights[1:]))
            - 0.15*max(heights))


def greedy_choice(piece, rows, rules):
    options = [(evaluate(board, result), commands)
               for commands, board, result in candidates(piece, rows, rules)]
    return max(options, key=lambda x: x[0]) if options else (-1e9, ["HARD_DROP"])


def choose(observation, mode, rng, rules=None):
    own = observation["self"]
    if rules is None:
        rules = Rules(**observation["rules"]) if "rules" in observation else Rules()
    if mode == "random":
        options = list(candidates(own["current"], own["board"], rules))
        return "PLAY", rng.choice(options)[0] if options else ["HARD_DROP"]
    best, commands = greedy_choice(own["current"], own["board"], rules)
    if own["can_hold"]:
        alternative = own["hold"] if own["hold"] is not None else own["next"]
        other, _ = greedy_choice(alternative, own["board"], rules)
        if other > best + 0.8:
            return "HOLD", None
    return "PLAY", commands


def serve(mode="greedy", bot_seed=0):
    rng = random.Random(bot_seed)
    cached_rules = None
    for line in sys.stdin:
        request = json.loads(line)
        observation = request["observation"]
        if "rules" in observation:
            cached_rules = Rules(**observation["rules"])
        kind, commands = choose(observation, mode, rng, cached_rules)
        response = {"request_id": request["request_id"], "type": kind}
        if kind == "PLAY":
            response["commands"] = commands
        print(json.dumps(response, separators=(",", ":")), flush=True)
