"""Deterministic duel reference engine. No third-party dependencies."""

__version__ = "0.5.3"
