"""Confirmed mechanics plus explicitly provisional, serializable profile."""
from dataclasses import asdict, dataclass, field
import hashlib
import json
import math
from . import __version__


LEGACY_PROFILE = "reference-provisional-v1"
PREVIOUS_PROFILE = "reference-provisional-v2"
V3_PROFILE = "reference-provisional-v3"
V4_PROFILE = "reference-provisional-v4"
V5_PROFILE = "reference-realtime-v5"
V51_PROFILE = "reference-realtime-v5.1"
V52_PROFILE = "reference-realtime-v5.2"
CURRENT_PROFILE = "reference-realtime-v5.3"
ENGINE_VERSIONS = {
    LEGACY_PROFILE: "0.1.0",
    PREVIOUS_PROFILE: "0.2.0",
    V3_PROFILE: "0.3.0",
    V4_PROFILE: "0.4.0",
    V5_PROFILE: "0.5.0",
    V51_PROFILE: "0.5.1",
    V52_PROFILE: "0.5.2",
    CURRENT_PROFILE: __version__,
}

LEGACY_KICKS_180 = ((0, 0), (-1, 0), (1, 0), (0, 1), (0, 2))
V4_KICKS_180 = {
    "0:2": ((0, 0), (0, 1), (1, 1), (-1, 1), (1, 0), (-1, 0)),
    "2:0": ((0, 0), (0, -1), (-1, -1), (1, -1), (-1, 0), (1, 0)),
    "1:3": ((0, 0), (1, 0), (1, 2), (1, 1), (0, 2), (0, 1)),
    "3:1": ((0, 0), (-1, 0), (-1, 2), (-1, 1), (0, 2), (0, 1)),
}


def default_spawns():
    # 0-based bottom-up origins. T cells: (3,20),(4,20),(5,20),(4,21).
    return {p: (3, 18 if p == "I" else 19) for p in "IOTSZJL"}


@dataclass
class Rules:
    profile: str = CURRENT_PROFILE
    width: int = 10
    height: int = 24
    main_height: int = 20
    normal_attack: tuple = (0, 0, 1, 2, 4)
    tspin_attack: tuple = (0, 2, 4, 6)
    b2b_bonus: int = 1
    perfect_clear_floor: int = 10
    overtime_first: int | None = None
    overtime_interval: int | None = None
    think_ms: int | None = None
    max_commands: int = 512
    max_response_bytes: int = 65536
    # Two program failures, or a program failure plus natural elimination:
    # v1-v3 use "draw"; v4+ use "fault_loses" so a legally playing side beats a fault.
    ambiguous_failure_outcome: str | None = None
    spawn_origins: dict = field(default_factory=default_spawns)
    # v1-v3 use a shared 5-offset tuple; v4+ use a 4-direction SRS+ dict with downward kicks.
    kicks_180: tuple | dict | None = None
    # Optional complete overrides: {"T:0:1": [[dx,dy], ...]}, O and I allowed.
    kicks_90_override: dict = field(default_factory=dict)
    first_think_ms: int | None = None
    # v4+ shared extensions
    time_bank_ms: int | None = None
    next_preview: int | None = None
    garbage_messiness: int | None = None
    garbage_cap: int | None = None
    cross_cancel: bool | None = None
    max_turns: int | None = None
    compact_observe: bool | None = None
    # v5 realtime 60 FPS virtual-clock extensions
    fps: int | None = None
    move_frames: int | None = None
    rotate_frames: int | None = None
    soft_drop_frames: int | None = None
    hold_frames: int | None = None
    lock_frames: int | None = None
    clear_frames: int | None = None
    special_clear_frames: int | None = None
    free_think_ms: int | None = None
    think_ms_per_frame: int | None = None
    max_think_frames: int | None = None
    garbage_delay_frames: int | None = None
    combo_block_limit: int | None = None
    overtime_first_frame: int | None = None
    overtime_interval_frames: int | None = None
    max_frames: int | None = None

    def __post_init__(self):
        if (self.width, self.height, self.main_height) != (10, 24, 20):
            raise ValueError("only the confirmed 10x24 board is supported")
        if not isinstance(self.profile, str) or not self.profile:
            raise ValueError("profile must be a nonempty string")
        if self.profile not in ENGINE_VERSIONS:
            raise ValueError("unsupported rules profile")

        is_v5 = self.is_realtime
        is_v4 = self.profile == V4_PROFILE
        is_v3 = self.profile == V3_PROFILE
        has_v4 = is_v4 or is_v5
        has_first_think = is_v3 or has_v4

        if is_v5:
            if self.overtime_first is not None or self.overtime_interval is not None or self.max_turns is not None:
                raise ValueError("realtime v5 uses frame-based overtime and max_frames")
        else:
            if self.overtime_first is None:
                self.overtime_first = 150 if is_v4 else 210
            if self.overtime_interval is None:
                self.overtime_interval = 8 if is_v4 else 10

        if self.think_ms is None:
            self.think_ms = 100 if has_v4 else (50 if is_v3 else 1000)
        if self.ambiguous_failure_outcome is None:
            self.ambiguous_failure_outcome = "fault_loses" if has_v4 else "draw"
        if self.kicks_180 is None:
            self.kicks_180 = {k: list(v) for k, v in V4_KICKS_180.items()} if has_v4 else LEGACY_KICKS_180

        positive_limits = ["think_ms", "max_commands", "max_response_bytes"]
        if not is_v5:
            positive_limits += ["overtime_first", "overtime_interval"]
        if has_first_think:
            if self.first_think_ms is None:
                self.first_think_ms = 1000
            positive_limits.append("first_think_ms")
        elif self.first_think_ms is not None:
            raise ValueError("historical profiles have a single thinking budget")

        v4_shared = (
            "time_bank_ms", "next_preview", "garbage_messiness",
            "garbage_cap", "cross_cancel", "compact_observe",
        )
        if has_v4:
            if self.time_bank_ms is None:
                self.time_bank_ms = 2000
            if self.next_preview is None:
                self.next_preview = 5
            if self.garbage_messiness is None:
                self.garbage_messiness = 25
            if self.garbage_cap is None:
                self.garbage_cap = 8
            if self.cross_cancel is None:
                self.cross_cancel = True
            if self.compact_observe is None:
                self.compact_observe = True
            positive_limits += ["next_preview", "garbage_cap"]
            if is_v4:
                if self.max_turns is None:
                    self.max_turns = 400
                positive_limits.append("max_turns")
            if type(self.time_bank_ms) is not int or self.time_bank_ms < 0:
                raise ValueError("time_bank_ms must be a nonnegative integer")
            if type(self.garbage_messiness) is not int or not 0 <= self.garbage_messiness <= 100:
                raise ValueError("garbage_messiness must be an integer between 0 and 100")
            if type(self.cross_cancel) is not bool or type(self.compact_observe) is not bool:
                raise ValueError("cross_cancel and compact_observe must be booleans")
        else:
            for field_name in (*v4_shared, "max_turns"):
                if getattr(self, field_name) is not None:
                    raise ValueError(f"{field_name} is not supported in {self.profile}")

        v5_fields = (
            "fps", "move_frames", "rotate_frames", "soft_drop_frames", "hold_frames",
            "lock_frames", "clear_frames", "special_clear_frames",
            "free_think_ms", "think_ms_per_frame", "max_think_frames",
            "garbage_delay_frames", "combo_block_limit",
            "overtime_first_frame", "overtime_interval_frames", "max_frames",
        )
        if is_v5:
            defaults = {
                "fps": 60, "move_frames": 2, "rotate_frames": 1, "soft_drop_frames": 2,
                "hold_frames": 2, "lock_frames": 8, "clear_frames": 12, "special_clear_frames": 16,
                "free_think_ms": 0 if self.has_cumulative_thinking else 30, "max_think_frames": 6,
                "garbage_delay_frames": 30, "combo_block_limit": 3,
                "overtime_first_frame": 3600, "overtime_interval_frames": 240, "max_frames": 10800,
            }
            if not self.has_cumulative_thinking:
                defaults["think_ms_per_frame"] = 25
                positive_limits.append("think_ms_per_frame")
            for k, v in defaults.items():
                if getattr(self, k) is None:
                    setattr(self, k, v)
            if self.has_cumulative_thinking and (self.free_think_ms or self.think_ms_per_frame is not None):
                raise ValueError("cumulative thinking counts all measured time at the match FPS")
            positive_limits += ["fps", "lock_frames", "overtime_first_frame", "overtime_interval_frames", "max_frames"]
            for k in ("move_frames", "rotate_frames", "soft_drop_frames", "hold_frames",
                      "clear_frames", "special_clear_frames", "free_think_ms",
                      "max_think_frames", "garbage_delay_frames", "combo_block_limit"):
                if type(getattr(self, k)) is not int or getattr(self, k) < 0:
                    raise ValueError(f"{k} must be a nonnegative integer")
        else:
            for field_name in v5_fields:
                if getattr(self, field_name) is not None:
                    raise ValueError(f"{field_name} is only supported in {CURRENT_PROFILE}")

        for name in positive_limits:
            if type(getattr(self, name)) is not int or getattr(self, name) <= 0:
                raise ValueError(f"{name} must be a positive integer")
        if self.ambiguous_failure_outcome not in ("draw", "no_contest", "fault_loses"):
            raise ValueError("ambiguous_failure_outcome must be draw, no_contest, or fault_loses")

        def offsets(value):
            return (isinstance(value, (list, tuple)) and len(value) > 0
                    and all(isinstance(p, (list, tuple)) and len(p) == 2
                            and all(type(n) is int for n in p) for p in value))

        if set(self.spawn_origins) != set("IOTSZJL"):
            raise ValueError("spawn_origins must specify all seven pieces")
        if not offsets(list(self.spawn_origins.values())):
            raise ValueError("spawn_origins require integer pairs")

        if isinstance(self.kicks_180, dict):
            if set(self.kicks_180) != {"0:2", "2:0", "1:3", "3:1"}:
                raise ValueError("directional kicks_180 must specify 0:2, 2:0, 1:3, 3:1")
            if any(not offsets(v) for v in self.kicks_180.values()):
                raise ValueError("kicks_180 entries require integer pairs")
        elif not offsets(self.kicks_180):
            raise ValueError("kicks_180 requires integer pairs")

        from .pieces import CELLS
        for p, (sx, sy) in self.spawn_origins.items():
            if any(not (0 <= sx + x < 10 and 0 <= sy + y < 24) for x, y in CELLS[p][0]):
                raise ValueError(f"{p} spawn is outside the board")
        for key, value in self.kicks_90_override.items():
            fields = key.split(":")
            if (len(fields) != 3 or fields[0] not in "IOTSZJL" or len(fields[0]) != 1
                    or fields[1] not in "0123" or len(fields[1]) != 1
                    or fields[2] not in "0123" or len(fields[2]) != 1
                    or (int(fields[2]) - int(fields[1])) % 4 not in (1, 3)
                    or not offsets(value)):
                raise ValueError("invalid 90-degree kick override")
        for name, length in (("normal_attack", 5), ("tspin_attack", 4)):
            values = getattr(self, name)
            if len(values) != length or any(type(n) is not int or n < 0 for n in values):
                raise ValueError(f"invalid {name}")
        if self.normal_attack[0] or self.tspin_attack[0]:
            raise ValueError("no-clear base attack must be zero")
        for name in ("b2b_bonus", "perfect_clear_floor"):
            if type(getattr(self, name)) is not int or getattr(self, name) < 0:
                raise ValueError(f"invalid {name}")

    @property
    def engine_version(self):
        return ENGINE_VERSIONS[self.profile]

    @property
    def is_realtime(self):
        return self.profile == V5_PROFILE or self.has_delayed_locks

    @property
    def has_delayed_locks(self):
        return self.profile == V51_PROFILE or self.has_scheduled_overtime

    @property
    def has_scheduled_overtime(self):
        return self.profile in (V52_PROFILE, CURRENT_PROFILE)

    @property
    def has_cumulative_thinking(self):
        return self.profile == CURRENT_PROFILE

    @property
    def is_v4_plus(self):
        return self.profile == V4_PROFILE or self.is_realtime

    def public(self):
        # JSON roundtrip produces detached lists, with no private RNG state.
        fields = asdict(self)
        for key in list(fields):
            if fields[key] is None:
                # Archived headers and rule hashes retain their exact original shape.
                del fields[key]
        return json.loads(json.dumps(fields))

    def turn_budget_ms(self, piece_index):
        if piece_index == 1 and self.first_think_ms is not None:
            return self.first_think_ms
        return self.think_ms

    def compute_think_frames(self, elapsed_seconds):
        return self.measure_think_frames(elapsed_seconds)[0]

    def measure_think_frames(self, elapsed_seconds, remainder=0):
        """Return whole think frames and the fraction to carry to the next hand."""
        if not self.is_realtime or self.max_think_frames == 0:
            return 0, 0
        if self.has_cumulative_thinking:
            # Keep fractions in billionths of a frame. Discard whole frames above
            # the per-hand cap, so a slow decision cannot penalize later hands.
            elapsed_ns = round(elapsed_seconds * 1_000_000_000)
            frames, remainder = divmod(elapsed_ns * self.fps + remainder, 1_000_000_000)
        else:
            ms = elapsed_seconds * 1000.0
            frames = math.ceil(max(0, ms - self.free_think_ms) / self.think_ms_per_frame)
            remainder = 0
        return min(self.max_think_frames, frames), remainder

    def pre_lock_frames(self, commands, hold_used, think_frames):
        cost = self.hold_frames if hold_used else 0
        for cmd in commands:
            if cmd in ("LEFT", "RIGHT"):
                cost += self.move_frames
            elif cmd in ("CW", "CCW", "ROT180"):
                cost += self.rotate_frames
            elif cmd == "DOWN":
                cost += self.soft_drop_frames
        return cost + max(0, min(self.max_think_frames, int(think_frames)))

    def post_lock_frames(self, lines, spin):
        if not lines:
            return self.lock_frames
        return self.lock_frames + (self.special_clear_frames if lines == 4 or spin == "full" else self.clear_frames)

    def overtime_count(self, frame):
        if frame < self.overtime_first_frame:
            return 0
        return 1 + (frame - self.overtime_first_frame) // self.overtime_interval_frames

    def fingerprint(self):
        from .pieces import geometry
        payload = {"rules": self.public(), "geometry": geometry(self)}
        return hashlib.sha256(json.dumps(payload, sort_keys=True,
                                        separators=(",", ":")).encode()).hexdigest()

    def overtime(self, turn):
        if self.is_realtime:
            return False
        return turn >= self.overtime_first and (turn - self.overtime_first) % self.overtime_interval == 0

    @classmethod
    def load(cls, path):
        with open(path, encoding="utf-8") as f:
            return cls(**json.load(f))
