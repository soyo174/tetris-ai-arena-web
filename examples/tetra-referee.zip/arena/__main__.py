import argparse
import asyncio
import json
from pathlib import Path
import sys
from . import __version__
from .bots import serve
from .config import Rules
from .pieces import geometry
from .runner import run_match, verify_replay


def main():
    parser = argparse.ArgumentParser(description=f"TETRA ARENA duel referee {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)
    bot = sub.add_parser("bot", help="JSONL baseline bot process")
    bot.add_argument("--mode", choices=("random", "greedy"), default="greedy")
    bot.add_argument("--bot-seed", type=int, default=0)
    match = sub.add_parser("match", help="run a full duel")
    match.add_argument("--a", choices=("random", "greedy"), default="greedy")
    match.add_argument("--b", choices=("random", "greedy"), default="random")
    match.add_argument("--a-command", help='external executable argv as JSON, e.g. ["./bot"]')
    match.add_argument("--b-command", help='external executable argv as JSON')
    match.add_argument("--seed", type=int, default=0)
    match.add_argument("--rules", help="JSON configuration; all overrides are recorded")
    match.add_argument("--replay", default="results/replay.jsonl")
    replay = sub.add_parser("verify", help="recompute a referee replay offline")
    replay.add_argument("path")
    export = sub.add_parser("export-rules", help="export public numeric tables for C++/other bots")
    export.add_argument("path")
    export.add_argument("--rules")
    render = sub.add_parser("render", help="offline HTML replay viewer")
    render.add_argument("path")
    render.add_argument("output")
    args = parser.parse_args()
    if args.command == "bot":
        serve(args.mode, args.bot_seed)
        return
    if args.command == "verify":
        print(json.dumps(verify_replay(args.path)))
        return
    if args.command == "render":
        from .viewer import render_replay
        render_replay(args.path, args.output)
        print(args.output)
        return
    rules = Rules.load(args.rules) if args.rules else Rules()
    if args.command == "export-rules":
        Path(args.path).write_text(json.dumps({"rules": rules.public(),
                                              "rules_sha256": rules.fingerprint(),
                                              "geometry": geometry(rules)}, indent=2), encoding="utf-8")
        return
    def argv(raw, mode):
        return json.loads(raw) if raw else [sys.executable, "-m", "arena", "bot", "--mode", mode]
    result = asyncio.run(run_match(argv(args.a_command, args.a), argv(args.b_command, args.b),
                                  seed=args.seed, rules=rules, replay=args.replay))
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
