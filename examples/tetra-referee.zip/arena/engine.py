"""Duel engine supporting historical turn-sync (v1-v4) and 60 FPS async realtime (v5)."""
from dataclasses import asdict, dataclass, field
import copy
import random
from .actions import ProgramError, execute, spawn, validate
from .board import Board
from .config import LEGACY_PROFILE, Rules
from .pieces import geometry
from .randomness import SevenBag, derived_seed
from .scoring import Chain, score


@dataclass
class Warning:
    lines: int
    due: int
    hole: int | None = None    # private until the segment rises (v1-v3 single hole)
    holes: list | None = None  # private per-row holes (v4+ messy garbage)

    def resolved_holes(self):
        if self.holes is not None:
            return list(self.holes)
        return [self.hole] * self.lines

    def snapshot_dict(self, is_v4_plus):
        if is_v4_plus:
            return {"lines": self.lines, "due": self.due, "holes": self.resolved_holes()}
        return {"lines": self.lines, "due": self.due, "hole": self.hole}


@dataclass
class PendingMove:
    commands: list | None
    failure: str | None
    hold_used: bool
    think_frames: int


@dataclass
class Player:
    board: Board = field(default_factory=Board)
    current: str = ""
    next_index: int = 1
    hold: str | None = None
    hold_used: bool = False
    warnings: list = field(default_factory=list)
    chain: Chain = field(default_factory=Chain)
    alive: bool = True
    total_lines: int = 0
    total_sent: int = 0
    # v5 realtime fields
    next_frame: int = 0
    pieces_placed: int = 0
    combo_blocks: int = 0
    pending: PendingMove | None = None


def cancel_old(warnings, attack, now_tick):
    """FIFO cancellation, then return remaining attack, due survivors and future survivors."""
    due, future = [], []
    for w in warnings:
        used = min(attack, w.lines)
        attack -= used
        left = w.lines - used
        if left:
            if w.holes is not None:
                packet = Warning(left, w.due, holes=list(w.holes[used:]))
            else:
                packet = Warning(left, w.due, hole=w.hole)
            (due if w.due <= now_tick else future).append(packet)
    return attack, due, future


def _generate_holes(rng, lines, messiness):
    hole = rng.randrange(10)
    holes = [hole]
    for _ in range(1, lines):
        if messiness > 0 and rng.randrange(100) < messiness:
            hole = (hole + 1 + rng.randrange(9)) % 10
        holes.append(hole)
    return holes


def _is_program_fault(reason):
    return reason not in ("hold_spawn_blocked", "spawn_blocked")


class Duel:
    def __init__(self, seed=0, rules=None):
        if type(seed) is not int:
            raise ValueError("seed must be an integer")
        self.rules = copy.deepcopy(rules or Rules())
        self.seed = seed
        legacy = self.rules.profile == LEGACY_PROFILE
        self.bags = [SevenBag(seed, None if legacy else side) for side in (0, 1)]
        self.players = [Player(current=bag.at(0)) for bag in self.bags]
        if self.rules.is_v4_plus:
            self.garbage_rng = [random.Random(derived_seed(seed, f"garbage-v4:{side}")) for side in (0, 1)]
        else:
            self.garbage_rng = [random.Random(derived_seed(seed, "garbage-v1")) for _ in range(2)]
        self.turn = 1
        self.frame = 0
        self.overtime_applied = 0
        self.actions = {}
        self.think_frames = {}
        # Live-only timing state. Replays supply the recorded whole frames.
        self._think_remainders = [0, 0]
        self.failures = {}
        self.finished = False
        self.winner = None
        self.outcome = "ongoing"

    def _next_overtime_frame(self):
        if not self.rules.has_scheduled_overtime:
            return float("inf")
        return self.rules.overtime_first_frame + self.overtime_applied * self.rules.overtime_interval_frames

    def active_sides(self):
        if not self.rules.is_realtime:
            return [0, 1]
        earliest = min(p.next_frame for p in self.players)
        if self.rules.has_delayed_locks and (
            self._next_overtime_frame() <= earliest or earliest > self.rules.max_frames
        ):
            return []
        return [i for i, p in enumerate(self.players) if p.next_frame == earliest and p.pending is None]

    def _side(self, side):
        if type(side) is not int or side not in (0, 1):
            raise ValueError("duel side must be 0 or 1")
        return self.players[side]

    def _ready(self, side):
        p = self._side(side)
        if self.finished or side in self.actions or side in self.failures:
            raise ProgramError("turn is already closed for this player")
        if self.rules.is_realtime and side not in self.active_sides():
            raise ProgramError("player is not active at the current frame")
        return p

    def observe(self, side):
        p = self._side(side)
        other = self.players[1-side]
        next_piece = self.bags[side].at(p.next_index)
        own_state = {
            "board": p.board.rows,
            "current": p.current,
            "next": next_piece,
            "hold": p.hold,
            "can_hold": not p.hold_used,
            "warnings": [{"lines": w.lines, "due": w.due} for w in p.warnings],
            "combo": p.chain.combo,
            "b2b": p.chain.b2b,
            "total_lines": p.total_lines,
            "total_sent": p.total_sent,
        }
        if self.rules.next_preview and self.rules.next_preview > 1:
            own_state["next_queue"] = [
                self.bags[side].at(p.next_index + offset)
                for offset in range(self.rules.next_preview)
            ]
        opponent_state = {"id": 1-side, "alive": other.alive, "board": other.board.rows}
        if self.rules.is_realtime:
            own_state["next_frame"] = p.next_frame
            own_state["pieces_placed"] = p.pieces_placed
            own_state["combo_blocks"] = p.combo_blocks
            opponent_state["next_frame"] = other.next_frame
            opponent_state["pieces_placed"] = other.pieces_placed
            include_static = not self.rules.compact_observe or (p.pieces_placed == 0 and not p.hold_used)
        else:
            include_static = not self.rules.compact_observe or (self.turn == 1 and not p.hold_used)
        payload = {
            "protocol": "tetris-duel-jsonl-v1",
            "turn": self.turn,
            "you": side,
            "rules_sha256": self.rules.fingerprint(),
            "self": own_state,
            "opponent": opponent_state,
        }
        if self.rules.is_realtime:
            payload["frame"] = self.frame
        if include_static:
            payload["rules"] = self.rules.public()
            payload["geometry"] = geometry(self.rules)
        return copy.deepcopy(payload)

    def hold(self, side):
        p = self._ready(side)
        if p.hold_used:
            raise ProgramError("second HOLD in one turn")
        old = p.current
        if p.hold is None:
            p.current = self.bags[side].at(p.next_index)
            p.next_index += 1
        else:
            p.current = p.hold
        p.hold = old
        p.hold_used = True
        if not p.board.fits(spawn(p.current, self.rules).cells()):
            self.failures[side] = "hold_spawn_blocked"
            return False
        return True

    def submit(self, side, commands, *, think_frames=0):
        self._ready(side)
        validate(commands, self.rules)
        if self.rules.is_realtime:
            if type(think_frames) is not int or not 0 <= think_frames <= self.rules.max_think_frames:
                raise ProgramError("invalid think_frames")
            self.think_frames[side] = think_frames
        self.actions[side] = list(commands)

    def submit_timed(self, side, commands, elapsed_seconds):
        self._side(side)
        frames, remainder = self.rules.measure_think_frames(elapsed_seconds, self._think_remainders[side])
        self.submit(side, commands, think_frames=frames)
        self._think_remainders[side] = remainder

    def fail(self, side, reason):
        self._ready(side)
        self.failures[side] = str(reason)

    def settle(self):
        if self.rules.is_realtime:
            return self._settle_realtime()
        return self._settle_turn_based()

    def _schedule_locks(self, ready, current_frame):
        for side in ready:
            player = self.players[side]
            commands = self.actions.get(side)
            think_frames = self.think_frames.get(side, 0)
            player.pending = PendingMove(commands, self.failures.get(side), player.hold_used, think_frames)
            if commands is not None:
                player.next_frame += self.rules.pre_lock_frames(commands, player.hold_used, think_frames)
            player.hold_used = False

        next_ready = min((p.next_frame for p in self.players if p.pending is None), default=float("inf"))
        next_lock = min((p.next_frame for p in self.players if p.pending is not None), default=float("inf"))
        overtime_frame = self._next_overtime_frame()
        if overtime_frame <= min(next_ready, next_lock, self.rules.max_frames):
            return overtime_frame, []
        if min(next_ready, next_lock) > self.rules.max_frames:
            return self.rules.max_frames, []
        # A seat can submit an immediate drop at the same frame as a queued lock.
        # Collect its decision before settling the locks on that frame.
        if next_ready <= next_lock:
            return current_frame, []
        return next_lock, [i for i, p in enumerate(self.players)
                           if p.pending is not None and p.next_frame == next_lock]

    def _settle_realtime(self):
        if self.finished:
            raise ProgramError("match is finished")
        active = self.active_sides()
        if any(i not in self.actions and i not in self.failures for i in active):
            raise ProgramError("active players must finish before settlement")
        step_index = self.turn
        event_frame = min(p.next_frame for p in self.players)
        moves = {i: PendingMove(self.actions.get(i), self.failures.get(i), self.players[i].hold_used,
                                self.think_frames.get(i, 0)) for i in active}
        if self.rules.has_delayed_locks:
            event_frame, active = self._schedule_locks(active, event_frame)
            moves = {i: self.players[i].pending for i in active}
        self.frame = event_frame

        records = [{"commands": moves[i].commands if i in moves else None, "attack": 0, "sent": 0,
                    "cancelled": 0, "risen": 0, "reasons": []} for i in (0, 1)]

        # Apply any overtime solid rows due by event_frame to both players.
        target_ot = self.rules.overtime_count(event_frame)
        solid_delta = max(0, target_ot - self.overtime_applied)
        if solid_delta > 0:
            for i, p in enumerate(self.players):
                if p.board.push(solid_delta):
                    records[i]["reasons"].append("solid_overflow")
            self.overtime_applied = target_ot

        # Phase 1: lock & score for active players only.
        attacks = [0, 0]
        locked_lines = [0, 0]
        for i in active:
            p = self.players[i]
            move = moves[i]
            if self.rules.has_delayed_locks:
                records[i]["hold_used"] = move.hold_used
            p.pending = None
            if move.failure is not None:
                records[i]["reasons"].append(move.failure)
                continue
            try:
                result = execute(p.board, p.current, move.commands, self.rules)
            except ProgramError as exc:
                records[i]["reasons"].append(str(exc))
                continue
            attacks[i] = score(result.lines, result.spin, result.perfect_clear, p.chain, self.rules)
            locked_lines[i] = result.lines
            before_lock = self.rules.pre_lock_frames(move.commands, move.hold_used, move.think_frames)
            after_lock = self.rules.post_lock_frames(result.lines, result.spin)
            records[i].update(lock=asdict(result), attack=attacks[i], frames=before_lock + after_lock,
                              think_frames=move.think_frames)
            delay = after_lock if self.rules.has_delayed_locks else before_lock + after_lock
            p.total_lines += result.lines
            p.pieces_placed += 1
            p.current = self.bags[i].at(p.next_index)
            p.next_index += 1
            p.next_frame = event_frame + delay

        # Phase 2: cancel old warnings & apply limited combo blocking + garbage cap for active players.
        outgoing = [0, 0]
        cap = self.rules.garbage_cap
        for i in active:
            p = self.players[i]
            before = sum(w.lines for w in p.warnings)
            remaining, due, future = cancel_old(p.warnings, attacks[i], event_frame)
            outgoing[i] = remaining
            records[i]["cancelled"] = before - sum(w.lines for w in due + future)

            if due and locked_lines[i] > 0 and p.combo_blocks < self.rules.combo_block_limit:
                # Limited Combo Blocking: defer due garbage while clearing, up to combo_block_limit.
                p.combo_blocks += 1
                deferred = [Warning(w.lines, event_frame, holes=w.resolved_holes()) for w in due]
                p.warnings = deferred + future
                records[i]["combo_blocked"] = True
            else:
                deferred = []
                budget = cap
                for w in due:
                    holes = w.resolved_holes()
                    take = min(len(holes), budget)
                    if take > 0:
                        budget -= take
                        records[i]["risen"] += take
                        if p.board.push_holes(holes[:take], solid_floor=True):
                            records[i]["reasons"].append("garbage_overflow")
                    leftover = holes[take:]
                    if leftover:
                        deferred.append(Warning(len(leftover), event_frame + 1, holes=leftover))
                p.warnings = deferred + future
                if locked_lines[i] == 0 or (due and not self.rules.has_delayed_locks):
                    p.combo_blocks = 0

        # Phase 2b: simultaneous frame cross-cancellation when both sides act on the same frame.
        if len(active) == 2 and self.rules.cross_cancel:
            mutual = min(outgoing[0], outgoing[1])
            if mutual:
                for i in (0, 1):
                    outgoing[i] -= mutual
                    records[i]["cancelled"] += mutual

        # Phase 3: deliver net outgoing attacks with frame delay.
        for sender in active:
            lines = outgoing[sender]
            records[sender]["sent"] = lines
            self.players[sender].total_sent += lines
            receiver = 1 - sender
            if lines:
                holes = _generate_holes(self.garbage_rng[receiver], lines, self.rules.garbage_messiness)
                due_frame = event_frame + self.rules.garbage_delay_frames
                self.players[receiver].warnings.append(Warning(lines, due_frame, holes=holes))

        # Phase 4: spawn checks, elimination & time limit.
        check_sides = (0, 1) if solid_delta > 0 else active
        for i in check_sides:
            p = self.players[i]
            if not p.board.fits(spawn(p.current, self.rules).cells()):
                records[i]["reasons"].append("next_spawn_blocked")
            p.alive = not records[i]["reasons"]
        for i in active:
            self.players[i].hold_used = False

        alive = [i for i, p in enumerate(self.players) if p.alive]
        next_clock = min(p.next_frame for p in self.players)
        overtime_only = self.rules.has_scheduled_overtime and solid_delta > 0
        time_limit_hit = event_frame >= self.rules.max_frames and not overtime_only
        if not self.rules.has_delayed_locks:
            time_limit_hit = time_limit_hit or next_clock > self.rules.max_frames
        self.finished = len(alive) < 2 or time_limit_hit
        self.winner = alive[0] if len(alive) == 1 else None
        if self.finished:
            if len(alive) == 1:
                self.outcome = "win"
            elif len(alive) == 2:
                self.outcome = "draw"
            else:
                fault_sides = [side for side, move in moves.items()
                               if move.failure is not None and _is_program_fault(move.failure)]
                if self.rules.ambiguous_failure_outcome == "fault_loses" and len(fault_sides) == 1:
                    self.winner = 1 - fault_sides[0]
                    self.outcome = "win"
                elif fault_sides:
                    self.outcome = ("draw" if self.rules.ambiguous_failure_outcome == "fault_loses"
                                    else self.rules.ambiguous_failure_outcome)
                else:
                    self.outcome = "draw"
        else:
            if self.rules.has_delayed_locks:
                next_clock = min(next_clock, self.rules.max_frames, self._next_overtime_frame())
            self.frame = next_clock

        event = {
            "turn": step_index,
            "frame": event_frame,
            "active": active,
            "players": records,
            "solid_risen": solid_delta,
            "finished": self.finished,
            "winner": self.winner,
            "outcome": self.outcome,
        }
        self.turn += 1
        self.actions.clear()
        self.think_frames.clear()
        self.failures.clear()
        return event

    def _settle_turn_based(self):
        if self.finished:
            raise ProgramError("match is finished")
        if any(i not in self.actions and i not in self.failures for i in (0, 1)):
            raise ProgramError("both players must finish before settlement")
        turn = self.turn
        attacks = [0, 0]
        records = [{"commands": self.actions.get(i), "attack": 0, "sent": 0,
                    "cancelled": 0, "risen": 0, "reasons": []} for i in (0, 1)]

        for i, p in enumerate(self.players):
            if i in self.failures:
                records[i]["reasons"].append(self.failures[i])
                continue
            try:
                result = execute(p.board, p.current, self.actions[i], self.rules)
            except ProgramError as exc:
                records[i]["reasons"].append(str(exc))
                continue
            attacks[i] = score(result.lines, result.spin, result.perfect_clear,
                               p.chain, self.rules)
            records[i].update(lock=asdict(result), attack=attacks[i])
            p.total_lines += result.lines
            p.current = self.bags[i].at(p.next_index)
            p.next_index += 1

        outgoing = [0, 0]
        solid_floor = self.rules.profile != LEGACY_PROFILE
        cap = self.rules.garbage_cap
        for i, p in enumerate(self.players):
            before = sum(w.lines for w in p.warnings)
            remaining, due, future = cancel_old(p.warnings, attacks[i], turn)
            outgoing[i] = remaining
            records[i]["cancelled"] = before - sum(w.lines for w in due + future)
            deferred = []
            budget = cap
            for w in due:
                if budget is None:
                    records[i]["risen"] += w.lines
                    if w.holes is not None:
                        overflow = p.board.push_holes(w.holes, solid_floor=solid_floor)
                    else:
                        overflow = p.board.push(w.lines, w.hole, solid_floor=solid_floor)
                    if overflow:
                        records[i]["reasons"].append("garbage_overflow")
                    continue
                holes = w.resolved_holes()
                take = min(len(holes), budget)
                if take > 0:
                    budget -= take
                    records[i]["risen"] += take
                    if p.board.push_holes(holes[:take], solid_floor=solid_floor):
                        records[i]["reasons"].append("garbage_overflow")
                leftover = holes[take:]
                if leftover:
                    deferred.append(Warning(len(leftover), turn + 1, holes=leftover))
            p.warnings = deferred + future

        if self.rules.cross_cancel:
            mutual = min(outgoing[0], outgoing[1])
            if mutual:
                for i in (0, 1):
                    outgoing[i] -= mutual
                    records[i]["cancelled"] += mutual

        for sender in (0, 1):
            lines = outgoing[sender]
            records[sender]["sent"] = lines
            self.players[sender].total_sent += lines
            receiver = 1 - sender
            if lines:
                if self.rules.is_v4_plus:
                    holes = _generate_holes(self.garbage_rng[receiver], lines, self.rules.garbage_messiness)
                    self.players[receiver].warnings.append(Warning(lines, turn + 1, holes=holes))
                else:
                    hole = self.garbage_rng[receiver].randrange(10)
                    self.players[receiver].warnings.append(Warning(lines, turn + 1, hole=hole))

        solid = self.rules.overtime(turn)
        for i, p in enumerate(self.players):
            if solid and p.board.push(1):
                records[i]["reasons"].append("solid_overflow")
            if not p.board.fits(spawn(p.current, self.rules).cells()):
                records[i]["reasons"].append("next_spawn_blocked")
            p.alive = not records[i]["reasons"]
            p.hold_used = False

        alive = [i for i, p in enumerate(self.players) if p.alive]
        turn_limit_hit = bool(self.rules.max_turns and turn >= self.rules.max_turns)
        self.finished = len(alive) < 2 or turn_limit_hit
        self.winner = alive[0] if len(alive) == 1 else None
        if self.finished:
            if len(alive) == 1:
                self.outcome = "win"
            elif len(alive) == 2:
                self.outcome = "draw"
            else:
                fault_sides = [side for side, reason in self.failures.items() if _is_program_fault(reason)]
                if self.rules.ambiguous_failure_outcome == "fault_loses" and len(fault_sides) == 1:
                    self.winner = 1 - fault_sides[0]
                    self.outcome = "win"
                elif fault_sides:
                    self.outcome = ("draw" if self.rules.ambiguous_failure_outcome == "fault_loses"
                                    else self.rules.ambiguous_failure_outcome)
                else:
                    self.outcome = "draw"
        event = {"turn": turn, "players": records, "solid_risen": int(solid),
                 "finished": self.finished, "winner": self.winner, "outcome": self.outcome}
        self.turn += 1
        self.actions.clear()
        self.failures.clear()
        return event

    def snapshot(self):
        """Referee-only state for offline training/replay. NEVER send to a bot."""
        v4_plus = self.rules.is_v4_plus
        rt = self.rules.is_realtime
        players = []
        for p in self.players:
            entry = {
                "board": copy.deepcopy(p.board.rows),
                "current": p.current,
                "hold": p.hold,
                "next_index": p.next_index,
                "warnings": [w.snapshot_dict(v4_plus) for w in p.warnings],
                "chain": asdict(p.chain),
                "alive": p.alive,
                "total_lines": p.total_lines,
                "total_sent": p.total_sent,
            }
            if rt:
                entry["next_frame"] = p.next_frame
                entry["pieces_placed"] = p.pieces_placed
                entry["combo_blocks"] = p.combo_blocks
            if self.rules.has_delayed_locks and p.pending is not None:
                entry["pending"] = asdict(p.pending)
            players.append(entry)
        snap = {"next_turn": self.turn, "finished": self.finished, "winner": self.winner,
                "outcome": self.outcome, "players": players}
        if rt:
            snap["frame"] = self.frame
            snap["overtime_applied"] = self.overtime_applied
        return snap
