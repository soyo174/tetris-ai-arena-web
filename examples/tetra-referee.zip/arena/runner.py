"""Concurrent local process runner. Bots receive observations, never Duel refs.

Time is measured per player's response interval after stdin.drain. Referee
work, HOLD refresh generation and waiting for the opponent are not charged.
"""
import asyncio
from contextlib import contextmanager
from dataclasses import dataclass
import json
import os
from pathlib import Path
import signal
import time
from .actions import ProgramError
from .engine import Duel
from .protocol import PROTOCOL, parse_response


class BotFault(ProgramError):
    pass


class ThinkingClock:
    """Pause the shared wall clock during synchronous referee work."""
    def __init__(self):
        self.excluded = 0.0

    def now(self):
        return time.perf_counter() - self.excluded

    @contextmanager
    def referee(self):
        start = time.perf_counter()
        try:
            yield
        finally:
            self.excluded += time.perf_counter() - start


@dataclass
class ProcessBot:
    process: object
    rules: object
    clock: object
    counter: int = 0

    @classmethod
    async def start(cls, argv, rules, clock=None):
        if not isinstance(argv, list) or not argv or any(not isinstance(s, str) for s in argv):
            raise ValueError("bot command must be a nonempty argv list")
        proc = await asyncio.create_subprocess_exec(
            *argv, stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL, limit=rules.max_response_bytes,
            start_new_session=(os.name == "posix"))
        bot = cls(proc, rules, clock or ThinkingClock())
        bot.set_running(False)
        return bot

    def set_running(self, running):
        if os.name == "posix":
            try:
                os.killpg(self.process.pid, signal.SIGCONT if running else signal.SIGSTOP)
            except ProcessLookupError:
                pass

    async def exchange(self, observation, remaining, *, bank_ms=None):
        with self.clock.referee():
            self.counter += 1
            request_id = str(self.counter)
            request = {"type": "OBSERVE", "request_id": request_id,
                       "remaining_ms": max(0, int(remaining*1000)),
                       "observation": observation}
            if bank_ms is not None:
                request["bank_ms"] = max(0, int(bank_ms))
            raw = (json.dumps(request, separators=(",", ":")) + "\n").encode()
        try:
            with self.clock.referee():
                self.set_running(True)
            self.process.stdin.write(raw)
            await asyncio.wait_for(self.process.stdin.drain(), max(1.0, self.rules.think_ms/1000))
        except (BrokenPipeError, ConnectionError, asyncio.TimeoutError) as exc:
            raise BotFault("bot_input_unavailable") from exc
        start = self.clock.now()
        reader = asyncio.create_task(self.process.stdout.readline())
        try:
            while True:
                left = remaining - (self.clock.now() - start)
                if left <= 0:
                    raise asyncio.TimeoutError
                try:
                    data = await asyncio.wait_for(asyncio.shield(reader), left)
                    break
                except asyncio.TimeoutError:
                    if self.clock.now() - start >= remaining:
                        raise
        except asyncio.TimeoutError as exc:
            raise BotFault("thinking_timeout") from exc
        except (ValueError, asyncio.LimitOverrunError) as exc:
            raise BotFault("response_too_large") from exc
        finally:
            with self.clock.referee():
                self.set_running(False)
            if not reader.done():
                reader.cancel()
                await asyncio.gather(reader, return_exceptions=True)
        elapsed = self.clock.now() - start
        if elapsed > remaining:
            raise BotFault("thinking_timeout")
        if not data:
            raise BotFault("bot_eof")
        with self.clock.referee():
            kind, commands = parse_response(data, request_id, self.rules)
        return kind, commands, elapsed

    async def close(self):
        if os.name == "posix":
            try:
                os.killpg(self.process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        elif self.process.returncode is None:
            self.process.kill()
        self.process.stdin.close()
        await self.process.communicate()


async def collect(game, side, bot, bank=None):
    piece_num = (game.players[side].pieces_placed + 1) if game.rules.is_realtime else game.turn
    base_budget = game.rules.turn_budget_ms(piece_num) / 1000
    bank_left = bank[side] if bank is not None else (game.rules.time_bank_ms or 0) / 1000
    turn_left = base_budget
    total_elapsed = 0.0
    exchanges = []
    while True:
        try:
            total_allowed = turn_left + bank_left
            if total_allowed <= 0:
                raise BotFault("thinking_timeout")
            with bot.clock.referee():
                observation = game.observe(side)
            if game.rules.time_bank_ms is not None and isinstance(bot, ProcessBot):
                kind, commands, elapsed = await bot.exchange(
                    observation, total_allowed, bank_ms=int(bank_left * 1000))
            else:
                kind, commands, elapsed = await bot.exchange(observation, total_allowed)
            total_elapsed += elapsed
            if elapsed <= turn_left:
                turn_left -= elapsed
            else:
                overage = elapsed - turn_left
                turn_left = 0.0
                bank_left = max(0.0, bank_left - overage)
            if bank is not None:
                bank[side] = bank_left
            exchanges.append({"type": kind, "commands": commands,
                              "elapsed_ms": round(elapsed*1000, 3)})
            if kind == "HOLD":
                with bot.clock.referee():
                    held = game.hold(side)
                if not held:
                    return exchanges
                continue
            with bot.clock.referee():
                game.submit_timed(side, commands, total_elapsed)
            return exchanges
        except (ProgramError, BrokenPipeError, ConnectionError) as exc:
            if bank is not None:
                bank[side] = bank_left
            with bot.clock.referee():
                game.fail(side, str(exc))
            return exchanges


async def run_match(argv_a, argv_b, seed=0, rules=None, replay=None):
    game = Duel(seed, rules)
    bots = []
    stream = None
    clock = ThinkingClock()
    bank = [(game.rules.time_bank_ms or 0) / 1000, (game.rules.time_bank_ms or 0) / 1000]
    try:
        bots.append(await ProcessBot.start(argv_a, game.rules, clock))
        bots.append(await ProcessBot.start(argv_b, game.rules, clock))
        if replay is not None:
            target = Path(replay)
            target.parent.mkdir(parents=True, exist_ok=True)
            stream = target.open("w", encoding="utf-8")
        def write(record):
            if stream:
                stream.write(json.dumps(record, separators=(",", ":")) + "\n")
                stream.flush()
        write({"type": "HEADER", "version": 1, "protocol": PROTOCOL,
               "engine_version": game.rules.engine_version,
               "seed": seed, "rules": game.rules.public(),
               "rules_sha256": game.rules.fingerprint(), "bots": [argv_a, argv_b]})
        last = None
        while not game.finished:
            active = game.active_sides()
            collected = await asyncio.gather(*(collect(game, i, bots[i], bank) for i in active))
            exchanges = [[], []]
            for side, log in zip(active, collected):
                exchanges[side] = log
            decision = {"holds": [p.hold_used for p in game.players],
                        "actions": {str(k): v for k, v in game.actions.items()},
                        "failures": {str(k): v for k, v in game.failures.items()}}
            if game.rules.is_realtime:
                decision["think_frames"] = {str(k): v for k, v in game.think_frames.items()}
            last = game.settle()
            write({"type": "TURN", "decision": decision, "event": last,
                   "exchanges": exchanges, "state": game.snapshot()})
        summary = {"winner": game.winner, "draw": game.outcome == "draw", "outcome": game.outcome,
                   "turns": game.turn-1, "seed": seed,
                   "rules_sha256": game.rules.fingerprint(),
                   "total_lines": [p.total_lines for p in game.players],
                   "total_sent": [p.total_sent for p in game.players],
                   "final_reasons": [p["reasons"] for p in last["players"]]}
        if game.rules.is_realtime:
            summary["frames"] = last["frame"]
            summary["pieces_placed"] = [p.pieces_placed for p in game.players]
        write({"type": "RESULT", **summary})
        return summary
    finally:
        if stream:
            stream.close()
        await asyncio.gather(*(bot.close() for bot in bots))


def verify_replay(path):
    """Recompute every turn/event from seed, profile and decisions; ignore wall clock."""
    from .config import Rules
    with open(path, encoding="utf-8") as stream:
        header = json.loads(next(stream))
        if (header.get("type") != "HEADER" or header.get("version") != 1
                or header.get("protocol") != PROTOCOL):
            raise ValueError("unsupported replay header")
        public_rules = header.get("rules")
        if not isinstance(public_rules, dict):
            raise ValueError("replay rules must be an explicit complete object")
        rules = Rules(**public_rules)
        if public_rules != rules.public():
            raise ValueError("replay rules must explicitly include every field")
        game = Duel(header["seed"], rules)
        if header.get("engine_version") != game.rules.engine_version:
            raise ValueError("replay engine version does not match its rules profile")
        if game.rules.fingerprint() != header["rules_sha256"]:
            raise ValueError("rules hash mismatch")
        count, ended = 0, False
        last_event = None
        for line in stream:
            record = json.loads(line)
            if ended:
                raise ValueError("records after RESULT")
            if record["type"] == "RESULT":
                expected_ok = (
                    game.finished and record["turns"] == count and record["winner"] == game.winner
                    and record["outcome"] == game.outcome
                    and record["draw"] == (game.outcome == "draw")
                    and record["seed"] == game.seed
                    and record["rules_sha256"] == game.rules.fingerprint()
                    and record["total_lines"] == [p.total_lines for p in game.players]
                    and record["total_sent"] == [p.total_sent for p in game.players]
                )
                if game.rules.is_realtime and last_event is not None:
                    expected_ok = (expected_ok
                                   and record.get("frames") == last_event["frame"]
                                   and record.get("pieces_placed") == [p.pieces_placed for p in game.players])
                if not expected_ok:
                    raise ValueError("invalid RESULT")
                ended = True
                continue
            if record["type"] != "TURN":
                raise ValueError("unknown replay record")
            decision = record["decision"]
            tfs = decision.get("think_frames", {})
            for i, held in enumerate(decision["holds"]):
                if held:
                    game.hold(i)
            for i, reason in decision["failures"].items():
                if int(i) not in game.failures:
                    game.fail(int(i), reason)
            for i, commands in decision["actions"].items():
                tf = tfs.get(str(i), 0) if game.rules.is_realtime else 0
                game.submit(int(i), commands, think_frames=tf)
            event = json.loads(json.dumps(game.settle()))
            last_event = event
            if event != record["event"] or game.snapshot() != record["state"]:
                raise ValueError(f"replay diverged at turn {count+1}")
            count += 1
        if not ended:
            raise ValueError("replay is incomplete")
        return {"verified_turns": count, "winner": game.winner}
