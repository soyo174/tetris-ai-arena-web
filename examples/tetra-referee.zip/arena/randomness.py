"""Private PRNG streams. Piece consumption never advances garbage RNG."""
import hashlib
import random


def derived_seed(seed, domain):
    return int.from_bytes(hashlib.sha256(f"{seed}:{domain}".encode()).digest(), "big")


class SevenBag:
    def __init__(self, seed, side=None):
        # A named seat selects v2. Omitting it preserves archived v1 streams.
        if side is not None and (type(side) is not int or side not in (0, 1)):
            raise ValueError("bag side must be 0 or 1")
        domain = "pieces-v1" if side is None else f"pieces-v2:{side}"
        self.rng = random.Random(derived_seed(seed, domain))
        self.sequence = []

    def at(self, index):
        while len(self.sequence) <= index:
            bag = list("IOTSZJL")
            self.rng.shuffle(bag)
            self.sequence.extend(bag)
        return self.sequence[index]
