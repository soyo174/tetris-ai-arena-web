"""Locked cells only. 0=empty, 1=ordinary, 2=garbage, 3=solid."""
EMPTY, NORMAL, GARBAGE, SOLID = range(4)


class Board:
    def __init__(self, rows=None):
        self.rows = ([list(r) for r in rows] if rows is not None
                     else [[EMPTY]*10 for _ in range(24)])
        if (len(self.rows) != 24 or any(len(r) != 10 for r in self.rows)
                or any(type(c) is not int or c not in range(4)
                       for r in self.rows for c in r)):
            raise ValueError("board requires 24 bottom-up rows of 10 cells (0..3)")

    def clone(self):
        return Board(self.rows)

    def fits(self, cells):
        return all(0 <= x < 10 and 0 <= y < 24 and self.rows[y][x] == EMPTY
                   for x, y in cells)

    def occupied_corner(self, x, y):
        # Rule counts side walls/floor, but not the ceiling as a T-spin corner.
        return x < 0 or x >= 10 or y < 0 or (y < 24 and self.rows[y][x] != EMPTY)

    def lock(self, cells):
        cells = tuple(cells)
        if len(cells) != 4 or len(set(cells)) != 4 or not self.fits(cells):
            raise ValueError("illegal lock")
        for x, y in cells:
            self.rows[y][x] = NORMAL

    def full_rows(self):
        return [y for y, r in enumerate(self.rows) if EMPTY not in r and SOLID not in r]

    def clear(self):
        full = set(self.full_rows())
        self.rows = [r for y, r in enumerate(self.rows) if y not in full]
        self.rows.extend([[EMPTY]*10 for _ in full])
        return len(full)

    def empty(self):
        return not any(any(row) for row in self.rows)

    def push(self, count, hole=None, *, solid_floor=True):
        """Rise a whole segment; hole=None denotes uncancellable solid rows.

        New garbage rises above the contiguous solid floor; only the playable
        area moves. Disable solid_floor solely when replaying the v1 profile.
        Return sticky overflow even when multiple lines leave the board.
        """
        if type(count) is not int or count < 0:
            raise ValueError("invalid rise count")
        if hole is not None and (type(hole) is not int or not 0 <= hole < 10):
            raise ValueError("invalid hole")
        if count == 0:
            return False
        floor = 0
        keep_floor = solid_floor and hole is not None
        if keep_floor:
            while floor < 24 and all(c == SOLID for c in self.rows[floor]):
                floor += 1
        added = min(count, 24 - floor)
        retained_top = 24 - added
        overflow = ((keep_floor and count > added)
                    or any(any(r) for r in self.rows[retained_top:]))
        row = [SOLID if hole is None else GARBAGE]*10
        if hole is not None:
            row[hole] = EMPTY
        self.rows = (self.rows[:floor] + [row[:] for _ in range(added)]
                     + self.rows[floor:retained_top])
        return overflow

    def push_holes(self, holes, *, solid_floor=True):
        """Rise garbage rows with per-row hole columns above the contiguous solid floor.

        holes[0] ends up lowest (just above the solid floor) or highest?
        Each hole is inserted in order at the bottom of the playable area (above
        solid floor), matching sequential push(1, hole) calls.
        """
        overflow = False
        for hole in holes:
            if self.push(1, hole, solid_floor=solid_floor):
                overflow = True
        return overflow
