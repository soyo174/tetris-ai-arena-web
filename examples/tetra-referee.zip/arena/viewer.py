"""Standalone offline viewer; intentionally shows referee post-settlement state."""
import json
from pathlib import Path


def render_replay(source, output):
    records = [json.loads(line) for line in Path(source).read_text(encoding="utf-8").splitlines()]
    data = json.dumps(records, ensure_ascii=True).replace("<", "\\u003c")
    html = '''<!doctype html><meta charset="utf-8"><title>Tetris Duel Replay</title>
<style>
body{background:#111526;color:#e5e9ff;font:16px system-ui;margin:28px auto;max-width:1000px;padding:0 20px}
h1{font-size:24px}canvas{background:#0a0d17;border:1px solid #596281;max-width:44vw;height:auto}
.boards{display:flex;gap:32px;justify-content:center}p{color:#b4bfdc}input{width:100%}
pre{white-space:pre-wrap;background:#1b2137;padding:16px;font-size:13px}button{padding:8px 16px}
</style><h1>Tetris Duel · Reference Replay</h1>
<p>Offline referee view · after simultaneous settlement · top 4 rows are spawn buffer</p>
<div class="boards"><div><h2>Player A</h2><canvas id="a" width="240" height="576"></canvas><p id="sa"></p></div>
<div><h2>Player B</h2><canvas id="b" width="240" height="576"></canvas><p id="sb"></p></div></div>
<p><button id="prev">Previous</button> <button id="play">Play / Pause</button> <button id="next">Next</button> <span id="label"></span></p>
<input id="slider" type="range" min="0" value="0"><pre id="info"></pre>
<script>
const records=__DATA__, turns=records.filter(r=>r.type==='TURN');let index=0,timer=null;
const $=id=>document.getElementById(id), colors=['#0a0d17','#90c8ff','#d4a5ed','#686e85'];
function draw(id,rows){const ctx=$(id).getContext('2d');ctx.clearRect(0,0,240,576);
 rows.forEach((r,y)=>r.forEach((c,x)=>{ctx.fillStyle=colors[c];ctx.fillRect(x*24,(23-y)*24,23,23)}));
 ctx.strokeStyle='#ffbc70';ctx.beginPath();ctx.moveTo(0,96);ctx.lineTo(240,96);ctx.stroke();}
function show(){const t=turns[index];if(!t)return;$('slider').value=index;
 t.state.players.forEach((p,i)=>{draw(i?'b':'a',p.board);$(i?'sb':'sa').textContent=
  `Lines ${p.total_lines} · Sent ${p.total_sent} · B2B ${p.chain.b2b} · Combo ${p.chain.combo}`});
 $('label').textContent=t.event.frame!==undefined
  ? `Time ${(t.event.frame/60).toFixed(2)}s (Step ${t.event.turn}/${turns.length})`
  : `Turn ${t.event.turn} / ${turns.length}`;
 $('info').textContent=JSON.stringify(t.event,null,2);}
$('slider').max=Math.max(0,turns.length-1);$('slider').oninput=e=>{index=+e.target.value;show()};
$('prev').onclick=()=>{index=Math.max(0,index-1);show()};
$('next').onclick=()=>{index=Math.min(turns.length-1,index+1);show()};
$('play').onclick=()=>{if(timer){clearInterval(timer);timer=null}else timer=setInterval(()=>{
 if(index>=turns.length-1){clearInterval(timer);timer=null;return}index++;show()},200)};show();
</script>'''.replace("__DATA__", data)
    Path(output).write_text(html, encoding="utf-8")
